import os 
from llama_index.core import Settings
from llama_index.core.callbacks import CallbackManager
from langfuse.llama_index import LlamaIndexCallbackHandler
from llama_index.core.callbacks import LlamaDebugHandler    
from llama_index.core.schema import Document,TextNode,MetadataMode
import pprint
from enum import Enum

import re
def my_chunking_tokenizer_fn(text:str):
    sentence_delimiters = re.compile(u'[。！？]')
    sentences = sentence_delimiters.split(text)
    return [s.strip() for s in sentences if s]

def print_nodes(nodes:list[TextNode],metadata_mode=MetadataMode.NONE):
    print('Count of nodes:',len(nodes))
    for index,node in enumerate(nodes):
        print("\n-----")
        print(f"Node {index}, ID: {node.node_id}")
        print(f'\ntext:{node.text}')
        print(f'\nmetadata:{node.metadata}')

        if hasattr(node, '\nrelationships'):
            print(f"Relationships: {node.relationships}")
            
        if hasattr(node, 'score'):
            print(f"Score: {node.score}")

        print("-----")

#打印对象属性
def print_attrs(obj, indent=0):
    print(' ' * indent + f'Object of type: {type(obj)}')   
    if hasattr(obj, '__dict__'):
        for key, value in obj.__dict__.items():
            print(' ' * (indent + 2) + f'{key}:')
            print_attrs(value, indent + 4)
    elif isinstance(obj, (list, tuple, set)):
        for i, item in enumerate(obj):
            print(' ' * (indent + 2) + f'Item {i}:')
            print_attrs(item, indent + 4)
    elif isinstance(obj, dict):
        for key, value in obj.items():
            print(' ' * (indent + 2) + f'{key}:')
            print_attrs(value, indent + 4)
    else:
        print(' ' * (indent + 2) + f'Value: {obj}')

#langfuse跟踪
def enable_trace():
    # Langfuse
    os.environ["LANGFUSE_SECRET_KEY"] = "sk-"
    os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-"
    os.environ["LANGFUSE_HOST"] = "http://x.x.x.x:3000"

    langfuse_callback_handler = LlamaIndexCallbackHandler()
    Settings.callback_manager = CallbackManager([langfuse_callback_handler])
    
class TraceType(Enum):
    LANGFUSE = "langfuse"
    LLAMA_DEBUG = "llama_debug"

class DebugUtils:
    def __init__(self, trace_type: TraceType):
        if trace_type == TraceType.LANGFUSE:
            enable_trace()
        elif trace_type == TraceType.LLAMA_DEBUG:
            self.enable_llama_debug_trace()

    def enable_llama_debug_trace(self):
        self.llama_debug = LlamaDebugHandler(print_trace_on_end=True)
        self.callback_manager = CallbackManager([self.llama_debug])
        Settings.callback_manager = self.callback_manager

    """
    CHUNKING = "chunking"
    NODE_PARSING = "node_parsing"
    EMBEDDING = "embedding"
    LLM = "llm"
    QUERY = "query"
    RETRIEVE = "retrieve"
    SYNTHESIZE = "synthesize"
    TREE = "tree"
    SUB_QUESTION = "sub_question"
    TEMPLATING = "templating"
    FUNCTION_CALL = "function_call"
    RERANKING = "reranking"
    EXCEPTION = "exception"
    AGENT_STEP = "agent_step"
    """
    
    def print_events_llm(self):
        events = self.llama_debug.get_event_pairs('llm')

        #发生了多少次llm调用
        print(f'Number of LLM calls: {len(events)}')
        #依次打印所有llm调用的messages
        for i, event in enumerate(events):
            print(f'\n==================LLM call {i+1} messages=====================')
            pprint.pprint(event[1].payload["messages"])
            print(f'\n==================LLM call {i+1} response=====================')
            pprint.pprint(event[1].payload["response"].message.content)


llama_debug = DebugUtils(TraceType.LLAMA_DEBUG)