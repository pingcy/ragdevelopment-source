import requests

# Define the base URL of your FastAPI server
base_url = "http://localhost:8090"

# Define the endpoint URL
endpoint = "/query"

# Define the request payload
payload = {
    "text": "value1"
}

# Send a POST request to the endpoint
response = requests.post(base_url + endpoint, json=payload)

# Check the response status code
if response.status_code == 200:
    # Request was successful
    data = response.json()
    # Process the response data here
    print(data)
else:
    # Request failed
    print("Request failed with status code:", response.status_code)