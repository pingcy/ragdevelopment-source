from multiprocessing.managers import BaseManager 

def test_query_index():

    manager = BaseManager(('', 5602), b'password')
    manager.register('query_index')
    manager.register('insert_into_index')
    manager.register('get_documents_list')
    manager.connect()

    response = manager.query_index('你好！')._getvalue()
    print(response)

if __name__ == "__main__":
    test_query_index()