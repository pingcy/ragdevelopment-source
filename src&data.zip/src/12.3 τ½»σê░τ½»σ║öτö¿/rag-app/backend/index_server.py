import os
import pickle
import chromadb
from multiprocessing import Lock
from multiprocessing.managers import BaseManager
from llama_index.core import Settings,SimpleDirectoryReader, VectorStoreIndex,StorageContext, load_index_from_storage
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI

#model
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='qwen2')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_ollama
Settings.embed_model=embedded_model_openai

#global index and stored docs
index = None
stored_docs = {}

# Lock for thread safety
lock = Lock()

# Path to save the index and stored docs
index_name = "./saved_index"
pkl_name = "./stored_documents.pkl"

# Port for the server
SERVER_PROT = 5602

# Initialize the index
def initialize_index():
    global index, stored_docs
    
    #vector store
    chroma = chromadb.HttpClient(host="localhost", port=8000)
    collection = chroma.get_or_create_collection(name="chat_docs_collection") 
    vector_store = ChromaVectorStore(chroma_collection=collection)

    with lock:
        if os.path.exists(index_name):
            storage_context =  StorageContext.from_defaults(persist_dir=index_name,vector_store=vector_store)
            index = load_index_from_storage(storage_context=storage_context)
        else:
            storage_context =  StorageContext.from_defaults(vector_store=vector_store)
            index = VectorStoreIndex([],storage_context=storage_context)
            index.storage_context.persist(persist_dir=index_name)
        
        if os.path.exists(pkl_name):
            with open(pkl_name, "rb") as f:
                stored_docs = pickle.load(f)

# Query the global index
def query_index(query_text):
    """Query the global index."""
    global index
    response = index.as_query_engine().query(query_text)
    return response

# Insert new document into global index
def insert_into_index(doc_file_path, doc_id=None):
    """Insert new document into global index."""
    global index, stored_docs
    document = SimpleDirectoryReader(input_files=[doc_file_path]).load_data()[0]
    if doc_id is not None:
        document.doc_id = doc_id

    with lock:

        index.insert(document)
        index.storage_context.persist(persist_dir=index_name)

        # Keep track of stored docs -- llama_index doesn't make this easy
        stored_docs[document.doc_id] = document.text[0:200]  # only take the first 200 chars
        
        with open(pkl_name, "wb") as f:
            pickle.dump(stored_docs, f)

    return

def get_documents_list():
    """Get the list of currently stored documents."""
    global stored_doc
    documents_list = []
    for doc_id, doc_text in stored_docs.items():
        documents_list.append({"id": doc_id, "text": doc_text})

    return documents_list

if __name__ == "__main__":
    
    print("initializing index...")
    initialize_index()

    print(f'Create server on port {SERVER_PROT}...')
    manager = BaseManager(('', SERVER_PROT), b'password')

    print("registering functions...")
    manager.register('query_index', query_index)
    manager.register('insert_into_index', insert_into_index)
    manager.register('get_documents_list', get_documents_list)
    server = manager.get_server()

    print("server started...")
    server.serve_forever()