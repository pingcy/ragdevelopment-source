import json
from typing import TypeVar
from fastapi import HTTPException, Request
from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)

def json_to_model(cls: T):
    async def get_json(request: Request) -> T:
        body = await request.body()
        try:
            data_dict = json.loads(body.decode("utf-8"))
            return cls(**data_dict)
        except (json.JSONDecodeError, ValidationError) as e:
            raise HTTPException(
                status_code=400, detail=f"Could not decode JSON: {str(e)}"
            )

    return get_json

def decode_sse_messages(sse_data):
    # 初始化结果列表
    output_message = sse_data
    decoded_messages = []

    # 按行分割SSE数据
    lines = sse_data.strip().split('\n')

    # 遍历每一行
    for line in lines:
        # 去除行尾的换行符
        line = line.rstrip()

        # 检查行是否以 'data:' 开头
        if line.startswith('data:'):
            # 提取 'data:' 后面的内容
            message = line.split(':', 1)[1].strip()
            if message.startswith('"') and message.endswith('"'):
                message = message[1:-1]

            # 将解码后的消息添加到结果列表中
            decoded_messages.append(message)

            # 将解码后的消息列表连接成字符串
            output_message = ''.join(decoded_messages)

            if '\\u' in output_message:
                try:
                    # 尝试对字符串进行解码
                    output_message = output_message.encode('utf-8').decode('unicode_escape')

                except UnicodeDecodeError:
                    pass
                
    return output_message
