from llama_parse import LlamaParse
from llama_index.readers.web import AsyncWebPageReader,BeautifulSoupWebReader,NewsArticleReader,SimpleWebPageReader
from llama_index.core.schema import Document,TextNode,MetadataMode
from typing import Any, Callable, Dict, List, Optional, Tuple
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.vector_stores.chroma import ChromaVectorStore
from multiprocessing import freeze_support, set_start_method
from llama_index.core.callbacks import CallbackManager
from llama_index.core.callbacks.schema import CBEventType
from llama_index.core.callbacks.base_handler import BaseCallbackHandler
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.agent import ReActAgent
from llama_index.llms.openai import OpenAI
from llama_index.core import VectorStoreIndex
from llama_index.core.objects import ObjectIndex,SimpleToolNodeMapping
from llama_index.agent.openai import OpenAIAgent
from queue import Queue
from pydantic import BaseModel
import chromadb
import pprint,chromadb,sys,os

llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='qwen2')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_openai
Settings.embed_model=embedded_model_openai

chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="docs_agent_collection") 
vector_store = ChromaVectorStore(chroma_collection=collection)

HOME_DIR='../backend'
DATA_DIR = f'{HOME_DIR}/data'
STOR_DIR = f'{HOME_DIR}/app/storage'

city_docs = {
    "Beijing":f'{DATA_DIR}/北京市.txt',
    "Guangzhou":f'{DATA_DIR}/广州市.txt',
    "Nanjing":f'{DATA_DIR}/南京市.txt',
    "Shanghai":f'{DATA_DIR}/上海市.txt'
}

class EventObject(BaseModel):
    """
    Represents an event from the LlamaIndex callback handler.

    Attributes:
        type (str): The type of the event, e.g. "function_call".
        payload (dict): The payload associated with the event.
    """

    type: str
    payload: dict

class StreamingCallbackHandler(BaseCallbackHandler):
    """Callback handler specifically designed to stream function calls to a queue."""

    def __init__(self, queue: Queue) -> None:
        """Initialize the base callback handler."""
        super().__init__([], [])
        self._queue = queue

    def on_event_start(
        self,
        event_type: CBEventType,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        """Run when an event starts and return id of event."""
        if event_type == CBEventType.FUNCTION_CALL:
            self._queue.put(
                EventObject(
                    type="function_call",
                    payload={
                        "arguments_str": str(payload["function_call"]),
                        "tool_str": str(payload["tool"].name),
                    },
                )
            )

    def on_event_end(
        self,
        event_type: CBEventType,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        """Run when an event ends."""
        if event_type == CBEventType.FUNCTION_CALL:
            self._queue.put(
                EventObject(
                    type="function_call_response",
                    payload={"response": payload["function_call_response"]},
                )
            )
        elif event_type == CBEventType.AGENT_STEP:
            self._queue.put(payload["response"])
        
    @property
    def queue(self) -> Queue:
        """Get the queue of events."""
        return self._queue

    def start_trace(self, trace_id: Optional[str] = None) -> None:
        """Run when an overall trace is launched."""
        pass

    def end_trace(
        self,
        trace_id: Optional[str] = None,
        trace_map: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        """Run when an overall trace is exited."""
        pass

def _create_doc_agent(name:str,callback_manager: CallbackManager):

    file = city_docs[name]

    print(f'Starting to create document agent for 【{name}】...\n')
    docs =SimpleDirectoryReader(input_files = [file]).load_data()
    splitter = SentenceSplitter(chunk_size=500,chunk_overlap=50)
    nodes = splitter.get_nodes_from_documents(docs)
    
    # Create a vector index
    if not os.path.exists(f"{STOR_DIR}/{name}"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"{STOR_DIR}/{name}")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"{STOR_DIR}/{name}",vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    query_engine = vector_index.as_query_engine(similarity_top_k=5)

    # Create a summary index
    summary_index = SummaryIndex(nodes)
    summary_engine = summary_index.as_query_engine(response_mode="tree_summarize")

    # Create a tool from the query engine
    query_tool = QueryEngineTool.from_defaults(query_engine=query_engine,
                                               name=f'query_tool',
                                               description=f'用于回答关于城市{name}的具体问题，包括经济、旅游、文化、历史等各方面')
    summary_tool = QueryEngineTool.from_defaults(query_engine=summary_engine,
                                                 name=f'summary_tool',
                                                 description=f"""
                                                             任何需要对城市{name}的各个方面进行全面总结的请求请使用本工具。
                                                             如果您想查询有关 {name} 的某些详细信息，请使用query_tool。
                                                             """
                                                )

    city_tools = [query_tool,summary_tool]

    # Create a tool agent from the tools
    doc_agent = ReActAgent.from_tools(city_tools,
                                      verbose=True,
                                      system_prompt=f"""
                                                    你是一个专门设计用来回答有关城市{name}信息查询的助手。
                                                    在回答问题时，你必须始终使用至少一个提供的工具；不要依赖先验知识。不要编造答案。
                                                    """,
                                     callback_manager=callback_manager
                                      )
    return doc_agent


def _create_doc_agents(callback_manager: CallbackManager):

    print('Creating document agents for all citys...\n')
    doc_agents_dict = {}
    for city in city_docs.keys():
        doc_agents_dict[city] = _create_doc_agent(city,callback_manager)

    return doc_agents_dict

def _create_top_agent(doc_agents: Dict,callback_manager: CallbackManager):

    all_tools = []
    for city in doc_agents.keys():

        city_summary = (
            f" 这部分包含了有关{city}的城市信息. "
            f" 如果需要回答有关{city}的任务问题，请使用这个工具.\n"
        )

        doc_tool = QueryEngineTool(
            query_engine=doc_agents[city],
            metadata=ToolMetadata(
                name=f"tool_{city}",
                description=city_summary,
            ),
        )
        all_tools.append(doc_tool)

    tool_mapping = SimpleToolNodeMapping.from_objects(all_tools)
    if not os.path.exists(f"{STOR_DIR}/top"):
        storage_context = StorageContext.from_defaults()
        obj_index = ObjectIndex.from_objects(
            all_tools, tool_mapping, VectorStoreIndex, storage_context=storage_context
        )
        storage_context.persist(persist_dir=f"{STOR_DIR}/top")
    else:
        storage_context = StorageContext.from_defaults(
            persist_dir=f"{STOR_DIR}/top"
        )
        index = load_index_from_storage(storage_context)
        obj_index = ObjectIndex(index, tool_mapping)

        
    print('Creating top agent...\n')
    top_agent = ReActAgent.from_tools(tool_retriever=obj_index.as_retriever(similarity_top_k=3),
                                       verbose=True,
                                       system_prompt="""
                                                     你是一个被设计来回答关于一组给定城市查询的助手。
                                                     任何时候请选择提供的工具来回答问题。
                                                     不得依赖已有的知识。不要编造答案。""",
                                       callback_manager=callback_manager
                                       )
    return top_agent


def get_agent():

    # define callback manager with streaming
    queue = Queue()
    handler = StreamingCallbackHandler(queue)
    callback_manager = CallbackManager([handler])

    doc_agents = _create_doc_agents(callback_manager)
    top_agent = _create_top_agent(doc_agents,callback_manager)

    return top_agent

if __name__ == '__main__':

    top_agent = get_agent()
    print('Starting to stream chat...\n')
    streaming_response = top_agent.streaming_chat_repl()
