from typing import List, cast

from fastapi.responses import StreamingResponse,JSONResponse

from threading import Thread
from backend.app.util import json_to_model,decode_sse_messages
from backend.app.index import get_agent,EventObject
from fastapi import APIRouter, Depends, HTTPException, Request, status
from llama_index.core.llms import MessageRole, ChatMessage
from llama_index.agent.openai import OpenAIAgent
from llama_index.core.chat_engine.types import StreamingAgentChatResponse
from pydantic import BaseModel
import logging
import json
from functools import lru_cache

chat_router = r = APIRouter()

class _Message(BaseModel):
    role: MessageRole
    content: str

class _ChatData(BaseModel):
    messages: List[_Message]

def convert_sse(obj: str | dict):
    """Convert the given object (or string) to a Server-Sent Event (SSE) event"""
    return "data: {}\n\n".format(json.dumps(obj,ensure_ascii=False))

@r.post("/hello")
async def hello(content: str):
    return 'Hello, ' + content

@lru_cache(maxsize=50)
def get_cached_agent(user_id: str) -> OpenAIAgent:
    return get_agent()

@r.post("")
async def chat(
    data: _ChatData,
    user_id: str = None
):
    print('userid:', user_id)
    agent = get_cached_agent(user_id)

    logger = logging.getLogger("uvicorn")

    # check preconditions and get last message
    if len(data.messages) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No messages provided",
        )
    lastMessage = data.messages.pop()
    if lastMessage.role != MessageRole.USER:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Last message must be from user",
        )
    
    # convert messages coming from the request to type ChatMessage
    messages = [
        ChatMessage(
            role=m.role,
            content=decode_sse_messages(m.content),
        )
        for m in data.messages
    ]

    print('------------Chat History---------\n')
    for message in messages:
        print(f'{message.role}: {message.content}')
        
    print(f'User: {lastMessage.content}')
    print('---------------------------------\n')

    """
    chat_result = agent.stream_chat(lastMessage.content, messages)

    def event_generator():
        for token in chat_result.response_gen:
            yield convert_sse(token)
    """
            
    thread = Thread(target=agent.stream_chat, args=(lastMessage.content, messages))
    thread.start()

    def event_generator():
        
        queue = agent.callback_manager.handlers[0].queue

        while True:
            next_item = queue.get(True, 60.0) 

            if isinstance(next_item, EventObject):
                if next_item.type.startswith('function_call'):
                    yield convert_sse(dict(next_item))
                
            elif isinstance(next_item, StreamingAgentChatResponse):
                response = cast(StreamingAgentChatResponse, next_item)
                for token in response.response_gen:
                    yield convert_sse(token)
                break
    
    return StreamingResponse(event_generator(), media_type="text/event-stream")


@r.post("/nostream")
async def chat_nostream(
    data: _ChatData
):
    agent = get_agent()

    # check preconditions and get last message
    if len(data.messages) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No messages provided",
        )
    lastMessage = data.messages.pop()
    if lastMessage.role != MessageRole.USER:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Last message must be from user",
        )
    
    # convert messages coming from the request to type ChatMessage
    messages = [
        ChatMessage(
            role=m.role,
            content=m.content,
        )
        for m in data.messages
    ]

    chat_result = agent.chat(lastMessage.content, messages)
    return JSONResponse(content={"text":str(chat_result)}, status_code=200)
