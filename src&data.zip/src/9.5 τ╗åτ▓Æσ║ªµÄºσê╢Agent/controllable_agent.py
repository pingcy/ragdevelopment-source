
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex

from llama_index.core.agent import AgentRunner
from llama_index.agent.openai import OpenAIAgentWorker, OpenAIAgent
from llama_index.agent.openai import OpenAIAgentWorker

import nest_asyncio
nest_asyncio.apply()

import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)

Settings.llm=llm_openai
Settings.embed_model=embedded_model_openai

chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="controllable_agent", metadata={"hnsw:space": "cosine"})
vector_store = ChromaVectorStore(chroma_collection=collection)

citys_dict = {
 '北京市':'beijing',
 '南京市':'nanjing',
 '广州市':'guangzhou',
 '上海市':'shanghai',
 '深圳市':'shenzhen'
}

def create_city_tool(name:str):

    print(f'Starting to create tool agent for 【{name}】...\n')
    city_docs = SimpleDirectoryReader(input_files=[f"../../data/citys/{name}.txt"]).load_data()
    nodes = SentenceSplitter(chunk_size=500,chunk_overlap=50).get_nodes_from_documents(city_docs)

    collection = chroma.get_or_create_collection(name=f"agent_{citys_dict[name]}", metadata={"hnsw:space": "cosine"})
    vector_store = ChromaVectorStore(chroma_collection=collection)

    if not os.path.exists(f"./storage/{citys_dict[name]}"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/{citys_dict[name]}")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/{citys_dict[name]}",vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    vector_query_engine = vector_index.as_query_engine()

    vector_query_engine_tool =  QueryEngineTool(
            query_engine=vector_query_engine,
            metadata=ToolMetadata(
                name=f"vector_tool_{citys_dict[name]}",
                description=(
                    f"Useful for questions related to specific aspects of {citys_dict[name]} (e.g. the history, arts and culture,"
                    " sports, demographics, or more)."
                ),
            ),
        )

    return vector_query_engine_tool

query_engine_tools = []
for city in citys_dict.keys():
    query_engine_tools.append(create_city_tool(city))

openai_step_engine = OpenAIAgentWorker.from_tools(
    query_engine_tools,verbose=True
)
agent = AgentRunner(openai_step_engine)

    
task_message = None
while task_message != "exit":
    task_message = input(">> 你: ")
    if task_message == "exit":
        break

    task = agent.create_task(task_message)

    response = None
    step_output = None
    message = None
    
    while message != "exit" and (not step_output or not step_output.is_last):

        #执行任务下一步
        if message is None or message == "":
            step_output = agent.run_step(task.task_id)
        else:
            step_output = agent.run_step(task.task_id, input=message)

        #如果任务没结束，允许用户输入
        if not step_output.is_last:
            message = input(">>  请补充任务反馈信息（留空继续，exit退出）: ")

    if step_output.is_last:
        print(">> 任务运行完成。")
        response = agent.finalize_response(task.task_id)
        print(f"Final Answer: {str(response)}")
    elif not step_output.is_last:
        print(">> 任务未完成，被丢弃。")
