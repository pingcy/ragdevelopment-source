import nest_asyncio
import pprint
import time
import chromadb
nest_asyncio.apply()

from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core import (
    SimpleDirectoryReader,
    StorageContext,
    VectorStoreIndex,
    Settings
)

from llama_index.core.llama_dataset.generator import RagDatasetGenerator,LabelledRagDataset
from llama_index.core.llama_dataset import LabelledEvaluatorDataset
from llama_index.core.evaluation import (
    FaithfulnessEvaluator,
    CorrectnessEvaluator,
    RelevancyEvaluator
)
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama

#模型设置
ollma_embedding = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16")
ollma = Ollama(model="llama3:8b")
Settings.llm = ollma
Settings.embed_model = ollma_embedding
#Settings.transformations = [SentenceSplitter(chunk_size=4096)]

#向量库
chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="evaluation", metadata={"hnsw:space": "cosine"})
vector_store = ChromaVectorStore(chroma_collection=collection)

#评估的原文档
eval_documents = SimpleDirectoryReader("../../data/MiniTruthfulQADataset/source_files/").load_data()

#评估的问题列表
eval_questions = LabelledRagDataset.from_json("../../data/MiniTruthfulQADataset/rag_dataset.json")

#data_generator = RagDatasetGenerator.from_documents(eval_documents,num_questions_per_chunk=2)
#eval_questions = data_generator.generate_dataset_from_nodes()

#评估：忠诚度（答案与conext）、相关性（答案与context，question）
faithfulness = FaithfulnessEvaluator()
relevancy = RelevancyEvaluator()
correctness = CorrectnessEvaluator()

#切换chunk_size
def evaluate_response_time_and_accuracy(chunk_size,num_questions=50):

    total_response_time = 0
    total_faithfulness = 0
    total_relevancy = 0
    total_correctness = 0

    #查询引擎
    node_parser = SentenceSplitter(chunk_size=chunk_size, chunk_overlap=0)
    nodes = node_parser.get_nodes_from_documents(eval_documents, show_progress=True)
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    print(f"\nTotal nodes: {len(nodes)}")

    vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
    query_engine = vector_index.as_query_engine(top_K=2)

    print('\nTotal number of questions:', len(eval_questions.examples))

    for index, question in enumerate(eval_questions.examples[:num_questions]):

        print(f"\nStart evaluating question【{index}】: {question.query}")
        start_time = time.time()
        response_vector = query_engine.query(question.query)

        #计算响应时间
        elapsed_time = time.time() - start_time
        
        #评估忠诚度
        faithfulness_result = faithfulness.evaluate_response(
            query=question.query, response=response_vector
        ).score
        
        #评估相关性
        relevancy_result = relevancy.evaluate_response(
            query=question.query, response=response_vector
        ).score

        #评估正确性
        correctness_result = correctness.evaluate_response(
            query=question.query, response=response_vector,reference_answer = question.reference_answer
        ).score

        total_response_time += elapsed_time
        total_faithfulness += faithfulness_result
        total_relevancy += relevancy_result
        total_correctness += correctness_result

        print(f"Response time: {elapsed_time:.2f}s, Faithfulness: {faithfulness_result}, Relevancy: {relevancy_result}, Correctness: {correctness_result}")

    average_response_time = total_response_time / num_questions
    average_faithfulness = total_faithfulness / num_questions
    average_relevancy = total_relevancy / num_questions
    average_correctness = total_correctness / num_questions

    return average_response_time, average_faithfulness, average_relevancy,average_correctness

for chunk_size in [512]:
  avg_time, avg_faithfulness, avg_relevancy,average_correctness = evaluate_response_time_and_accuracy(chunk_size)
  print(f"Chunk size {chunk_size} - Average Response time: {avg_time:.2f}s, Average Faithfulness: {avg_faithfulness:.2f}, Average Relevancy: {avg_relevancy:.2f}, Average Correctness: {average_correctness:.2f}")