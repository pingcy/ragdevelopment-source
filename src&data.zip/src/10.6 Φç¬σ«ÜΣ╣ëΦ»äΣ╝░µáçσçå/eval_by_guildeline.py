from typing import Any, Callable, Dict, List, Optional, Tuple
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.vector_stores.chroma import ChromaVectorStore
from multiprocessing import freeze_support, set_start_method
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.llms.openai import OpenAI
from llama_index.core import VectorStoreIndex
import chromadb
import pprint,chromadb,sys,os
from llama_index.core.evaluation import FaithfulnessEvaluator, CorrectnessEvaluator, RelevancyEvaluator,SemanticSimilarityEvaluator,AnswerRelevancyEvaluator,ContextRelevancyEvaluator
from llama_index.core.llama_dataset import LabelledRagDataset
import myprompts

from llama_index.core.evaluation import GuidelineEvaluator
import nest_asyncio
nest_asyncio.apply()

llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='qwen2')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_ollama
Settings.embed_model=embedded_model_openai

chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="docs_agent_collection") 
vector_store = ChromaVectorStore(chroma_collection=collection)

HOME_DIR='/Users/pingcy/本地开发/rag'
DATA_DIR = f'{HOME_DIR}/data/citys'
STOR_DIR = f'./storage'

city_docs = {
    "Beijing":f'{DATA_DIR}/北京市.txt',
    "Guangzhou":f'{DATA_DIR}/广州市.txt',
    "Nanjing":f'{DATA_DIR}/南京市.txt',
    "Shanghai":f'{DATA_DIR}/上海市.txt'
}

def _create_doc_engine(name:str):

    file = city_docs[name]

    print(f'Starting to create document agent for 【{name}】...\n')
    docs =SimpleDirectoryReader(input_files = [file]).load_data()
    splitter = SentenceSplitter(chunk_size=500,chunk_overlap=50)
    nodes = splitter.get_nodes_from_documents(docs)
    
    # Create a vector index
    if not os.path.exists(f"{STOR_DIR}/{name}"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"{STOR_DIR}/{name}")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"{STOR_DIR}/{name}",vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    query_engine = vector_index.as_query_engine(similarity_top_k=5)

    return query_engine

query_engine = _create_doc_engine('Nanjing')
query = "南京的气候怎么样"
response = query_engine.query(query)

GUIDELINES = [
    "回答应该完全回答了输入问题。",
    "回答应该避免模糊或含糊不清的用词。",
    "回答应该在可能时使用明确的统计数据或数字。"
]

evaluators = [
    GuidelineEvaluator(guidelines=guideline,eval_template=myprompts.MY_GUILD_EVAL_TEMPLATE)
    for guideline in GUIDELINES
]

for guideline, evaluator in zip(GUIDELINES, evaluators):
    eval_result = evaluator.evaluate_response(
        query= "南京有多少人口？南京的气候怎么样？",
        response=response
    )
    print("====================================")
    print(f"Guideline: {guideline}")
    print(f"Pass: {eval_result.passing}")
    print(f"Feedback: {eval_result.feedback}")