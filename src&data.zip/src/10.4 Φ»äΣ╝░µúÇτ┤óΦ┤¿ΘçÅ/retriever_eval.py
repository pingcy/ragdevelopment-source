
from typing import Any, Callable, Dict, List, Optional, Tuple
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.vector_stores.chroma import ChromaVectorStore
from multiprocessing import freeze_support, set_start_method
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.llms.openai import OpenAI
from llama_index.core import VectorStoreIndex
import chromadb
import pprint,chromadb,sys,os
from llama_index.core.evaluation import FaithfulnessEvaluator, CorrectnessEvaluator, RelevancyEvaluator
from llama_index.core.llama_dataset.generator import RagDatasetGenerator
from llama_index.core.evaluation import RetrieverEvaluator


llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='qwen2')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_ollama
Settings.embed_model=embedded_model_openai

documents = SimpleDirectoryReader(input_files=["../../data/citys/南京市.txt"]).load_data()
node_parser = SentenceSplitter(chunk_size=1024)
nodes = node_parser.get_nodes_from_documents(documents)
for idx, node in enumerate(nodes):
    node.id_ = f"node_{idx}"

vector_index = VectorStoreIndex(nodes)
retriever = vector_index.as_retriever(similarity_top_k=2)

from llama_index.core.evaluation import (
    generate_question_context_pairs,
    EmbeddingQAFinetuneDataset,
)

QA_GENERATE_PROMPT_TMPL = """
以下是上下文信息:
---------------------
{context_str}
---------------------
你是位专业教授。你的任务是基于以上的上下文信息，为即将到来的考试设置 {num_questions_per_chunk} 个问题。
这些问题必须基于提供的上下文信息生成，并确保上下文信息能够回答这些问题。确保每一行只有一个独立的问题。不要有多余解释。不要问题编号。"
"""

 
print("Generating question-context pairs...")
qa_dataset = generate_question_context_pairs(
    nodes, 
    llm=llm_ollama, 
    num_questions_per_chunk=1,
    qa_generate_prompt_tmpl=QA_GENERATE_PROMPT_TMPL
)    

print("Saving dataset...")
qa_dataset.save_json("retriever_eval_dataset.json")  

print("Loading dataset...")
qa_dataset = EmbeddingQAFinetuneDataset.from_json("retriever_eval_dataset.json")
eval_querys = list(qa_dataset.queries.items())
for eval_id,eval_query in eval_querys[:10]:
    print(f"Query: {eval_query}")

""" 
from llama_index.core.evaluation import RetrieverEvaluator
metrics = ["mrr", "hit_rate"]
retriever_evaluator = RetrieverEvaluator.from_metric_names(
    metrics, retriever=retriever
)

for eval_id,eval_query in eval_querys[:10]:
    expect_docs = qa_dataset.relevant_docs[eval_id]

    print(f"Query: {eval_query}, Expected docs: {expect_docs}")

    eval_result = retriever_evaluator.evaluate(query=eval_query,expected_ids=expect_docs)
    print(eval_result)  """
 

#eval_results = retriever_evaluator.evaluate_dataset(qa_dataset)

""" 
retriever_evaluator = RetrieverEvaluator.from_metric_names(
    ["mrr", "hit_rate"], retriever=retriever
)

retriever_evaluator.evaluate(
    query="南京的气候怎么样", expected_ids=["node_id1", "node_id2"]
)
 """