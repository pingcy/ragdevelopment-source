from llama_index.core import VectorStoreIndex
from llama_index.experimental.query_engine import PandasQueryEngine
from llama_index.core.schema import IndexNode
from llama_index.llms.openai import OpenAI
from llama_index.core.response.pprint_utils import pprint_response
from llama_parse import LlamaParse
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings
from llama_index.readers.web import AsyncWebPageReader,BeautifulSoupWebReader,NewsArticleReader,SimpleWebPageReader
from llama_index.experimental.query_engine import PandasQueryEngine
import pickle
from llama_index.readers.file import PyMuPDFReader
from typing import List
from llama_index.llms.openai import OpenAI
from llama_index.llms.langchain import LangChainLLM
from langchain_community.llms import QianfanLLMEndpoint
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.core.node_parser import UnstructuredElementNodeParser
from llama_index.readers.file.flat import FlatReader
from llama_index.core.retrievers import RecursiveRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core import PromptTemplate
import pprint
import pandas as pd
import chromadb
import camelot
from typing import Any, Dict, List, Optional, Sequence, Tuple, cast
from pathlib import Path
import io,os,sys
sys.path.append("..")
from tools import print_nodes
import pandas as pd

#llm & embedding model
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm = llm_openai
Settings.embed_model = embedded_model_openai

#vector store
chroma = chromadb.HttpClient(host="localhost", port=8000)

#此处更改默认的摘要提示词为中文
DEFAULT_SUMMARY_QUERY_STR = """\
尽可能的结合上下文，用中文详细介绍表格内容。\
这个表格是关于什么的？给出一个摘要说明（想象你正在为这个表格添加一个新的标题和摘要），\
如果提供了上下文，请输出真实/现有的表格标题/说明。\
如果提供了上下文，请输出真实/现有的表格ID。\
"""

#需要加载的网页URL
url = ['https://qwenlm.github.io/zh/blog/qwen1.5/']

#解析出来的节点持久化，以免反复调用LLM
nodes_save_path = './storage/nodes/qwen1.5.pkl'
node_table_save_path = './storage/nodes/qwen1.5_{node_id}.pkl'

#从node中获取内容转化为pandas的dataframe
def node_to_df(node):
    prompt_rewrite_temp = """\
    你是一个数据清洗工具。请去除内容中前面的说明部分，仅保留表格内容输出。不要多余解释和多余空格。不要修改和编造表格内容。\n
    内容：{content}
    表格内容：
    """
    prompt_rewrite = PromptTemplate(prompt_rewrite_temp)
    llm = OpenAI(model="gpt-3.5-turbo")

    node_table_save_file = node_table_save_path.format(node_id=node.id_)
    if not os.path.exists(node_table_save_file):
        response = llm.predict(
            prompt_rewrite, content=node.get_content(metadata_mode='llm')
        )
        pickle.dump(response, open(node_table_save_file, "wb"))
    else:
        response = pickle.load(open(node_table_save_file, "rb"))

    df = pd.read_csv(io.StringIO(response), sep="|", engine="python")
    return df

#创建基础引擎
def create_base_engine():

    #加载网页，生成docs
    web_loader = SimpleWebPageReader()
    docs = web_loader.load_data(url)

    #分割成nodes，并做持久化
    node_parser = UnstructuredElementNodeParser(summary_query_str=DEFAULT_SUMMARY_QUERY_STR)
    if nodes_save_path is None or not os.path.exists(nodes_save_path):
        raw_nodes = node_parser.get_nodes_from_documents(docs)
        pickle.dump(raw_nodes, open(nodes_save_path, "wb"))
    else:
        raw_nodes = pickle.load(open(nodes_save_path, "rb"))

    #对其中IndexNode的做解析，找到其指向的node，然后将该node中的表格生成对应的query engine
    raw_nodes_dict =  {doc.id_: doc for doc in raw_nodes}
    query_engine_dict = {}
    nonbase_node_ids = set()
    for node in raw_nodes:
        if isinstance(node, IndexNode):

            child_node = raw_nodes_dict[node.index_id]
            df = node_to_df(child_node)

            #跟踪信息
            print("\n=================================================")
            print(f"Table node content: {child_node.get_content()}\n")

            df_query_engine = PandasQueryEngine(df)
            query_engine_dict[node.index_id] = df_query_engine

            #记录已经被IndexNode引用的node，后续去除
            nonbase_node_ids.add(node.index_id)
    
    #去除已经被IndexNode引用的node，剩下的就是base node
    base_nodes = []
    for node in raw_nodes:
        if node.node_id not in nonbase_node_ids:
            base_nodes.append(node)

    #对base_nodes构建vector index
    collection = chroma.get_or_create_collection(name=f"qwen1.5")
    vector_store = ChromaVectorStore(chroma_collection=collection)
    if not os.path.exists(f"./storage/vectorindex/qwen1.5"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(base_nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/qwen1.5")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/vectorindex/qwen1.5",
                                                        vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    vector_retriever = vector_index.as_retriever(similarity_top_k=2)
    recursive_retriever = RecursiveRetriever(
            "vector",
            retriever_dict={"vector": vector_retriever},
            #node_dict=node_mappings,
            query_engine_dict=query_engine_dict,
            verbose=True,
    )
    query_engine = RetrieverQueryEngine.from_args(recursive_retriever)   
    return query_engine
    
#创建查询引擎并对话
engine = create_base_engine()
response = engine.query('HumanEval基准测试中，哪些模型参与了测试？平均分是多少？最高分多少？')
pprint_response(response)
 