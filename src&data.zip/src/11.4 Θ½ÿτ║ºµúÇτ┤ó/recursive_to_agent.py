from llama_parse import LlamaParse
from llama_index.readers.web import AsyncWebPageReader,BeautifulSoupWebReader,NewsArticleReader,SimpleWebPageReader
from llama_index.core.schema import Document,TextNode,MetadataMode
from typing import Any, Callable, Dict, List, Optional, Tuple
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.core.retrievers import RecursiveRetriever
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.vector_stores.chroma import ChromaVectorStore
from multiprocessing import freeze_support, set_start_method
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.agent import ReActAgent
from llama_index.llms.openai import OpenAI
from llama_index.core import VectorStoreIndex
from llama_index.core.objects import ObjectIndex
from llama_index.agent.openai import OpenAIAgent
from llama_index.core.schema import IndexNode
import pprint
import chromadb
import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()
import os
os.environ["LLAMA_CLOUD_API_KEY"] = "llx-*"

os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_openai
Settings.embed_model=embedded_model_openai

chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="recursive_agent") 
vector_store = ChromaVectorStore(chroma_collection=collection)

#创建针对某个文档的file_agent
def create_file_agent(file,name):

    print(f'Starting to create tool agent for 【{name}】...\n')

    docs =SimpleDirectoryReader(input_files = [file]).load_data()
    splitter = SentenceSplitter(chunk_size=500,chunk_overlap=0)
    nodes = splitter.get_nodes_from_documents(docs)
    
    # Create a vector index

    if not os.path.exists(f"./storage/vectorindex/allcitys/{name}"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/allcitys/{name}")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/vectorindex/allcitys/{name}",
                                                        vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    query_engine = vector_index.as_query_engine(similarity_top_k=3)

    # Create a summary index
    summary_index = SummaryIndex(nodes)
    summary_engine = summary_index.as_query_engine(response_mode="tree_summarize")

    # Create a tool from the query engine
    query_tool = QueryEngineTool.from_defaults(query_engine=query_engine,name=f'query_tool',description=f'Use if you want to query details about {name}')
    summary_tool = QueryEngineTool.from_defaults(query_engine=summary_engine,name=f'summary_tool',description=f'Use ONLY IF you want to get a holistic summary of the documents. DO NOT USE if you want to query some details about {name}.')

    # Create a tool agent from the tools
    file_agent = ReActAgent.from_tools([query_tool,summary_tool],verbose=True,
                                                system_prompt=f"""
                                                                You are a specialized agent designed to answer queries about {name}.
                                                                You must ALWAYS use at least one of the tools provided when answering a question; do NOT rely on prior knowledge.DO NOT fabricate answer.
                                                                """
                                      )
    return file_agent


names = ['Nanjing','Beijing','Shanghai']
files = ['../../data/citys/南京市.txt','../../data/citys/北京市.txt','../../data/citys/上海市.txt']

#创建不同文档的agent
print('===============================================\n')
print('Creating file agents for different documents...\n')
file_agents_dict = {}
for name, file in zip(names, files):
    file_agent = create_file_agent(file, name)
    file_agents_dict[name] = file_agent

print('===============================================\n')
print('Creating top level nodes from tool agents...\n')
index_nodes = []
query_engine_dict = {}
for name in names:
    doc_summary = f"这个内容包含关于城市{name}的维基百科文章。如果您需要查找城市{name}的具体事实，请使用此索引。\n如果您想分析多个城市，请不要使用此索引。"
    node = IndexNode(
        index_id = name,
        text=doc_summary,
    )
    index_nodes.append(node)
    query_engine_dict[name] = file_agents_dict[name]

top_index = VectorStoreIndex(index_nodes)
top_retriever = top_index.as_retriever(similarity_top_k=1)
recursive_retriever = RecursiveRetriever(
    "vector",
    retriever_dict={"vector": top_retriever},
    query_engine_dict=query_engine_dict,
    verbose=True,
)

query_engine = RetrieverQueryEngine.from_args(recursive_retriever)   
response = query_engine.query('南京市有哪些著名的旅游景点呢？')
print(response) 

""" 
#文档agent转化为tool
print('===============================================\n')
print('Creating top level nodes from tool agents...\n')
index_nodes = []
for name in names:
    doc_summary = (
        f"这个内容包含关于城市{name}的维基百科文章。如果您需要查找城市{name}的具体事实，请使用此索引。\n如果您想分析多个城市，请不要使用此索引。"
    )
    node = IndexNode(
        text=doc_summary, index_id=name, obj=file_agents_dict[name]
    )
    index_nodes.append(node)

# define top-level retriever
vector_index = VectorStoreIndex(
    objects=index_nodes,
)
query_engine = vector_index.as_query_engine(similarity_top_k=1, verbose=True)
response = query_engine.query('南京市有哪些著名的旅游景点呢？')
print(response) """
