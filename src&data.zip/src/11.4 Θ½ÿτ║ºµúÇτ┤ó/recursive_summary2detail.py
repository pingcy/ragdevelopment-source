from pathlib import Path
from tqdm.asyncio import tqdm
from llama_index.readers.file import PDFReader
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,KeywordTableIndex
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.response.notebook_utils import display_source_node
from llama_index.core.retrievers import RecursiveRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core import VectorStoreIndex
from llama_index.core.response.pprint_utils import pprint_response
from llama_index.core.agent import AgentRunner
from llama_index.core.async_utils import run_jobs
from llama_index.core.schema import IndexNode
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.agent.openai import OpenAIAgentWorker, OpenAIAgent
from llama_index.agent.openai import OpenAIAgentWorker
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import load_index_from_storage
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore.types import BaseDocumentStore
from llama_index.core.vector_stores import (
    FilterOperator,
    MetadataFilter,
    MetadataFilters,
)
from llama_index.core.extractors import (
    SummaryExtractor,
    QuestionsAnsweredExtractor,
)
from llama_index.vector_stores.chroma import ChromaVectorStore
import json
import chromadb
import nest_asyncio,asyncio
nest_asyncio.apply()
import pprint,chromadb,sys,os
sys.path.append("..")
from tools import print_nodes

#vector db
chroma = chromadb.HttpClient(host="localhost", port=8000)

#llm & embedding model
os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='llama3:8b') 
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm = llm_openai
Settings.embed_model = embedded_model_openai


docs = SimpleDirectoryReader(input_files=["../../data/c-rag.pdf"]).load_data()

def create_base_index():
 
    splitter = SentenceSplitter(chunk_size=1024,chunk_overlap=0)
    nodes = splitter.get_nodes_from_documents(docs)

    for idx,node in enumerate(nodes):
        node.id_ = f"node_{idx}"

    collection = chroma.get_or_create_collection(name=f"crag")
    vector_store = ChromaVectorStore(chroma_collection=collection)

    if not os.path.exists(f"./storage/vectorindex/crag"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/crag")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/vectorindex/crag",
                                                        vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    return vector_index,nodes

base_index,base_nodes  = create_base_index()
base_retriever = base_index.as_retriever(similarity_top_k=2)
#nodes = base_retriever.retrieve("please explain the concept of Action Trigger in c-rag?")

def create_subnodes_index(base_nodes):
    sub_chunk_sizes = [128, 256]
    sub_node_parsers = [SentenceSplitter(chunk_size=subsize,chunk_overlap=0) for subsize in sub_chunk_sizes]

    all_nodes = []
    for base_node in base_nodes:
        for n in sub_node_parsers:
            sub_nodes = n.get_nodes_from_documents([base_node])
            for sn in sub_nodes:
                indexnode_sn = IndexNode.from_text_node(sn, base_node.node_id)
                all_nodes.append(indexnode_sn)
    
        all_nodes.append(IndexNode.from_text_node(base_node, base_node.node_id))

    collection = chroma.get_or_create_collection(name=f"crag-subnodes")
    vector_store = ChromaVectorStore(chroma_collection=collection)

    if not os.path.exists(f"./storage/vectorindex/crag-subnodes"):
        print('Creating subnodes vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(all_nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/crag-subnodes")
    else:
        print('Loading subnodes vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/vectorindex/crag-subnodes",
                                                        vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    return vector_index, all_nodes


def create_summary_nodes(base_nodes):

    extractor = SummaryExtractor(summaries=["self"], show_progress=True)
    summary_dict = {}

    if not os.path.exists(f"./storage/metadata/summarys.json"):
        print('Extract new summary...\n')
        summarys = extractor.extract(base_nodes)
        
        for node,summary in zip(base_nodes,summarys):
            summary_dict[node.node_id] = summary

        with open('./storage/metadata/summarys.json', "w") as fp:
                json.dump(summary_dict, fp)
    else:
        print('Loading summary from storage...\n')
        with open('./storage/metadata/summarys.json', "r") as fp:
            summary_dict = json.load(fp)

    all_nodes = []

    for node_id, summary in summary_dict.items():
        all_nodes.append(IndexNode(text=summary["section_summary"], index_id=node_id))

    all_nodes.extend(IndexNode.from_text_node(base_node, base_node.node_id) for base_node in base_nodes)
    
    collection = chroma.get_or_create_collection(name=f"crag-summarynodes")
    vector_store = ChromaVectorStore(chroma_collection=collection)

    if not os.path.exists(f"./storage/vectorindex/crag-summarynodes"):
        print('Creating summary nodes vector index...\n')
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(all_nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/crag-summarynodes")
    else:
        print('Loading summary nodes vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/vectorindex/crag-summarynodes",
                                                        vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    return vector_index, all_nodes


""" 
summary_index,summary_nodes = create_summary_nodes(base_nodes)
summary_retriever = summary_index.as_retriever(similarity_top_k=2)
summary_nodes_dict = {n.node_id: n for n in summary_nodes}
recursive_retriever = RecursiveRetriever(
    "root_retriever",
    retriever_dict={"root_retriever": summary_retriever},
    node_dict=summary_nodes_dict,
    verbose=True,
)
recursive_query_engine = RetrieverQueryEngine.from_args(recursive_retriever)
response = recursive_query_engine.query("please explain the concept of Action Trigger in c-rag?please answer in Chinese")
pprint_response(response)
 """

""" 
sub_index,sub_nodes = create_subnodes_index(base_nodes)

sub_retriever = sub_index.as_retriever(similarity_top_k=2)
sub_nodes_dict = {n.node_id: n for n in sub_nodes}

recursive_retriever = RecursiveRetriever(
    "root_retriever",
    retriever_dict={"root_retriever": sub_retriever},
    node_dict=sub_nodes_dict,
    verbose=True,
)

recursive_query_engine = RetrieverQueryEngine.from_args(recursive_retriever)
response = recursive_query_engine.query("please explain the concept of Action Trigger in c-rag?please answer in Chinese")
pprint_response(response)

"""
