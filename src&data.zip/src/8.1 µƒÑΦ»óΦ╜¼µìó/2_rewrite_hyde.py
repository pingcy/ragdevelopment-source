
from llama_index.core.indices.query.query_transform import HyDEQueryTransform,DecomposeQueryTransform
from llama_index.llms.openai import OpenAI
from llama_index.core import PromptTemplate
import pprint

hyde_prompt_temp = """\
请生成一段文字来回答输入问题\n
尽可能含有更多的关键细节\n
{context_str}
生成内容：
"""
hyde_prompt = PromptTemplate(hyde_prompt_temp)

llm = OpenAI(model="gpt-3.5-turbo")
hyde = HyDEQueryTransform(llm=llm)
hyde.update_prompts({'hyde_prompt':hyde_prompt})

query_bundle = hyde.run("南京市的人口是多少？经济发展如何？")
print(query_bundle.__dict__) 
