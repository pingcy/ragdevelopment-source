from llama_index.core import PromptTemplate
from llama_index.llms.openai import OpenAI

prompt_rewrite_temp = """\
您是一个聪明的查询生成器。请根据我的输入查询生成多个搜索查询问题。生成与以下输入查询相关的{num_queries}个查询问题 \n
注意每个查询占一行 \n
我的查询：{query}
生成查询列表：
"""
prompt_rewrite = PromptTemplate(prompt_rewrite_temp)
llm = OpenAI(model="gpt-3.5-turbo")

def rewrite_query(query: str, num: int = 3):
    response = llm.predict(
        prompt_rewrite, num_queries=num, query=query
    )

    # 假设LLM将每个查询放在一行上
    queries = response.split("\n")
    return queries

print(rewrite_query("请介绍北京这座城市？"))
