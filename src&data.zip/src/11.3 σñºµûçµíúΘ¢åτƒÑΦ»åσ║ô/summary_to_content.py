from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,KeywordTableIndex
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.response.pprint_utils import pprint_response
from llama_index.core.query_engine import TransformQueryEngine
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.retrievers.bm25 import BM25Retriever
from llama_index.core.retrievers import BaseRetriever
from typing import List
from llama_index.core.schema import NodeWithScore
from llama_index.core.query_engine import MultiStepQueryEngine
from llama_index.core.indices.query.query_transform import HyDEQueryTransform,DecomposeQueryTransform,StepDecomposeQueryTransform
from llama_index.llms.openai import OpenAI
import pprint
from llama_index.core import QueryBundle
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.agent import AgentRunner
from llama_index.agent.openai import OpenAIAgentWorker, OpenAIAgent
from llama_index.agent.openai import OpenAIAgentWorker
from tqdm.asyncio import tqdm
from llama_index.core.async_utils import run_jobs
from llama_index.core.schema import IndexNode
from llama_index.core.storage.docstore.types import BaseDocumentStore
from llama_index.core.vector_stores import (
    FilterOperator,
    MetadataFilter,
    MetadataFilters,
)

import nest_asyncio,asyncio
nest_asyncio.apply()

import pprint,chromadb,sys,os
sys.path.append("..")
#from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
import os
#enable_trace()

#llm & embedding model
os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='llama3:8b')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm = llm_openai
Settings.embed_model = embedded_model_openai

#vector db
chroma = chromadb.HttpClient(host="localhost", port=8000)

citys_dict = {
 '北京市':'beijing',
 '南京市':'nanjing',
 '广州市':'guangzhou',
 '上海市':'shanghai',
 '深圳市':'shenzhen'
}

#读取成documents
print('Loading documents...\n')
city_docs = SimpleDirectoryReader(input_files=[
                                    "../../data/citys/南京市.txt",
                                    "../../data/citys/北京市.txt",
                                    "../../data/citys/上海市.txt",
                                    "../../data/citys/广州市.txt"]).load_data()

#设置index_id，后续用来创建对应的summary_node
for doc in city_docs:
    doc.metadata['index_id'] = os.path.splitext(doc.metadata["file_name"])[0]

#给每个doc生成一个summary，用来构造summary_node
def generate_docs_summary():

    #持久化
    def save_summary_txt(doc_id, summary_txt):
        summary_dir = "./storage/summary_txt"
        if not os.path.exists(summary_dir):
            os.makedirs(summary_dir)
        summary_file = os.path.join(summary_dir, f"{doc_id}.txt")
        with open(summary_file, "w") as f:
            f.write(summary_txt)

    #加载
    def load_summary_txt(doc_id):
        summary_dir = "./storage/summary_txt"
        summary_file = os.path.join(summary_dir, f"{doc_id}.txt")
        if os.path.exists(summary_file):
            with open(summary_file, "r") as f:
                return f.read()
        return None

    #借助summaryindex来生成摘要信息，也可以直接用llm生成
    def generate_summary_txt(doc):
        summary_index = SummaryIndex.from_documents([doc])
        query_engine = summary_index.as_query_engine(llm=llm_dash, response_mode="tree_summarize")
        summary_txt = query_engine.query("请用中文生成摘要信息")
        summary_txt = str(summary_txt)
        save_summary_txt(doc.metadata["index_id"], summary_txt)
        return summary_txt

    #对每个doc生成summary，保存到metadata，且不参与embed和llm输入
    print('Generate document summary...\n')
    for doc in city_docs:
        doc_id = doc.metadata["index_id"]
        summary_txt = load_summary_txt(doc_id)

        if summary_txt is None:
            summary_txt = generate_summary_txt(doc)

        doc.metadata["summary_text"] = summary_txt
        doc.excluded_embed_metadata_keys = ["summary_text"]
        doc.excluded_llm_metadata_keys = ["summary_text"]

generate_docs_summary()

#创建二级vector index，针对所有documents，并持久化，减少重复构建
def create_vector_index():
 
    splitter = SentenceSplitter(chunk_size=500,chunk_overlap=0)
    nodes = splitter.get_nodes_from_documents(city_docs)

    collection = chroma.get_or_create_collection(name=f"details_citys")
    vector_store = ChromaVectorStore(chroma_collection=collection)

    if not os.path.exists(f"./storage/vectorindex/allcitys"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/allcitys")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/vectorindex/allcitys",
                                                        vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    return vector_index

docs_index = create_vector_index()

#辅助函数：针对单个doc，构建一个基于摘要的index_node
def create_doc_index_node(doc):

    summary_txt = doc.metadata["summary_text"]
    filters = MetadataFilters(
        filters=[
            MetadataFilter(
                key="index_id", operator=FilterOperator.EQ, value=doc.metadata["index_id"]
            ),
        ]
    )

    #创建单个文档的summary的node，注意此处obj是用来进行递归检索的检索器
    index_node = IndexNode(
        index_id = doc.metadata["index_id"],
        text = summary_txt,
        metadata = doc.metadata,
        obj = docs_index.as_retriever(filters = filters)
    )

    return index_node


#构建摘要的索引
def  create_summary_index():

    summary_collection = chroma.get_or_create_collection(name=f"summary_allcitys")
    vector_store = ChromaVectorStore(chroma_collection=summary_collection)\

    index_nodes = []

    for doc in city_docs:
        index_node = create_doc_index_node(doc)
        index_nodes.append(index_node)

    print('Creating summary index (for recursive retrieve)...\n')
    storage_context =  StorageContext.from_defaults(vector_store=vector_store)
    vector_index = VectorStoreIndex(objects=index_nodes,storage_context=storage_context)
    vector_index.storage_context.persist(persist_dir=f"./storage/vectorindex/summarycitys")
    
    return vector_index

summary_index = create_summary_index()


print('Creating query engine...\n')
retriever = summary_index.as_retriever(similarity_top_k=1,verbose=True)
query_engine = RetrieverQueryEngine(retriever)

print('Query executing...\n')
response = query_engine.query('上海市的人口多少')

pprint_response(response,show_source=True)