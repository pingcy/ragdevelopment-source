from llama_index.readers.web import SimpleWebPageReader
from llama_index.core.schema import Document
from typing import List
from llama_index.core import SimpleDirectoryReader, VectorStoreIndex, SummaryIndex
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core.tools import QueryEngineTool
from llama_index.core.agent import ReActAgent
from llama_index.core.objects import ObjectIndex
from llama_index.agent.openai import OpenAIAgent
import chromadb
import sys
import os
from llama_index.core.settings import Settings
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
import os

llm_openai = OpenAI(model='gpt-4o-mini')
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_openai
Settings.embed_model=embedded_model_openai

chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="agentic_rag") 
vector_store = ChromaVectorStore(chroma_collection=collection)

#创建针对某个文档的tool_agent
def create_tool_agent(file,name):

    print(f'Starting to create tool agent for 【{name}】...\n')

    docs =SimpleDirectoryReader(input_files = [file]).load_data()
    splitter = SentenceSplitter(chunk_size=500,chunk_overlap=50)
    nodes = splitter.get_nodes_from_documents(docs)
    
    # Create a vector index

    if not os.path.exists(f"./storage/{name}"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"./storage/{name}")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"./storage/{name}",vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    query_engine = vector_index.as_query_engine(similarity_top_k=5)

    # Create a summary index
    summary_index = SummaryIndex(nodes)
    summary_engine = summary_index.as_query_engine(response_mode="tree_summarize")

    # Create a tool from the query engine
    query_tool = QueryEngineTool.from_defaults(query_engine=query_engine,name=f'query_tool',description=f'Use if you want to query details about {name}')
    summary_tool = QueryEngineTool.from_defaults(query_engine=summary_engine,name=f'summary_tool',description=f'Use ONLY IF you want to get a holistic summary of the documents. DO NOT USE if you want to query some details about {name}.')

    # Create a tool agent from the tools
    tool_agent = ReActAgent.from_tools([query_tool,summary_tool],verbose=True,
                                                system_prompt=f"""
                                                                You are a specialized agent designed to answer queries about {name}.
                                                                You must ALWAYS use at least one of the tools provided when answering a question; do NOT rely on prior knowledge.DO NOT fabricate answer.
                                                                """
                                      )
    return tool_agent


names = ['c-rag','self-rag','kg-rag']
files = ['../../data/c-rag.pdf','../../data/self-rag.pdf','../../data/kg-rag.pdf']

#创建不同文档的agent
print('===============================================\n')
print('Creating tool agents for different documents...\n')
tool_agents_dict = {}
for name, file in zip(names, files):
    tool_agent = create_tool_agent(file, name)
    tool_agents_dict[name] = tool_agent

#文档agent转化为tool
print('===============================================\n')
print('Creating tools from tool agents...\n')
all_tools = []
for name in names:
    agent_tool = QueryEngineTool.from_defaults(
        query_engine=tool_agents_dict[name], 
        name=f"tool_{name.replace("-", "")}",
        description=f"Use this tool if you want to answer any questions about {name}."
    )
    all_tools.append(agent_tool)

print('===============================================\n')
print('Creating tool retrieve index...\n')
obj_index = ObjectIndex.from_objects(
    all_tools,
    index_cls=VectorStoreIndex,
)
tool_retriever = obj_index.as_retriever(similarity_top_k=2,verbose=True)    


tools_needed = tool_retriever.retrieve("What is the Adaptive retrieval in the c-RAG?")
print('Tools needed to answer the question:')
for tool in tools_needed:
    print(tool.metadata.name) 

#创建top_agent
print('===============================================\n')
print('Creating top agent...\n')
top_agent = OpenAIAgent.from_tools(tool_retriever=tool_retriever,verbose=True,system_prompt="""You are an agent designed to answer queries over a set of given papers.
                                                     Please always use the tools provided to answer a question.Do not rely on prior knowledge.""",
                                                     )

top_agent.chat_repl()

""" 
print('===============================================\n')
print('Starting chat...\n')
while True:
    user_input = input("Please enter your message:")
    if user_input.lower() == "quit":
        break
    if user_input.lower() == "":
        continue
    response = top_agent.chat(user_input)
    print('\n===============================================\n')
    print("Final response:",response)
    print('\n===============================================\n') """

#查询
#response = top_agent.chat('What is the Adaptive retrieval with threshold in the self-RAG?')

#response = top_agent.chat('Please introduce Retrieval Evaluator in C-RAG pattern?')

#response = top_agent.chat('Compare the  Adaptive retrieval of self-RAG and the Retrieval Evaluator of c-RAG')