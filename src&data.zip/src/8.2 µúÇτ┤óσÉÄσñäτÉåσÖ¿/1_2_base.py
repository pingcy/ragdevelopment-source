from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent,NodeWithScore
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.postprocessor import MetadataReplacementPostProcessor,SimilarityPostprocessor,KeywordNodePostprocessor,MetadataReplacementPostProcessor
from llama_index.core.postprocessor.types import BaseNodePostprocessor
from llama_index.core.response.pprint_utils import pprint_response
from llama_index.core.data_structs import Node
from llama_index.core import QueryBundle

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore
from typing import List,Optional

import pprint
import chromadb
import sys
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
import re
enable_trace()

#model
llm = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm
Settings.embed_model=embedded_model

#documents
#docs = SimpleDirectoryReader(input_files=["../../data/yiyan.txt"]).load_data()
docs = [Document(text="小麦手机是小麦公司最新出的第十代手机产品。\
                       采用了中国最先进的国产红旗CPU芯片。\
                       采用了6.95寸的OLED显示屏幕与5000毫安的电池容量。\
                       操作系统是最新的澎湃OS 3.0，兼容现有的安卓APP，是一款高性能的智能手机。\
                       与苹果手机相比较，小麦手机具有更高的性价比。",metadata={'window':'this is window text'})]
nodes = SentenceSplitter(chunk_size=50,chunk_overlap=0).get_nodes_from_documents(docs)
vector_index = VectorStoreIndex(nodes)


""" 
class MyNodePostprocessor(BaseNodePostprocessor):
    def _postprocess_nodes(
        self, nodes: List[NodeWithScore], query_bundle: Optional[QueryBundle]
    ) -> List[NodeWithScore]:
        
        pattern = r"过滤正则表达式"
        filtered_nodes = []
        for node in nodes:
            if not re.search(pattern, node.text):
                filtered_nodes.append(node)
        nodes = filtered_nodes
        return nodes

query_engine = vector_index.as_query_engine(
    node_postprocessors=[
        MyNodePostprocessor()
    ]
)
response = query_engine.query('小麦手机的显示屏是多大的？')
pprint_response(response) 
"""

retriever = VectorIndexRetriever(vector_index,similarity_top_k=1)
nodes_with_scores = retriever.retrieve('小麦手机')

print('===================Before postprocessing===================')
print_nodes(nodes_with_scores,MetadataMode.ALL)

processor = MetadataReplacementPostProcessor(target_metadata_key="window")
filtered_nodes = processor.postprocess_nodes(nodes_with_scores)

print('===================After postprocessing===================')
print_nodes(filtered_nodes,MetadataMode.ALL)