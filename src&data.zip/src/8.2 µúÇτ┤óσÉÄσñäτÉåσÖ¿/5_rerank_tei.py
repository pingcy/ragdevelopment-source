
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.postprocessor import MetadataReplacementPostProcessor,FixedRecencyPostprocessor,EmbeddingRecencyPostprocessor,LongContextReorder
from llama_index.postprocessor.cohere_rerank import CohereRerank
from llama_index.core.response.pprint_utils import pprint_response

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore

import pprint
import chromadb
import sys
import os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

import requests
from typing import List, Optional
from llama_index.core.bridge.pydantic import Field, PrivateAttr
from llama_index.core.postprocessor.types import BaseNodePostprocessor
from llama_index.core.schema import NodeWithScore, QueryBundle

class BgeRerank(BaseNodePostprocessor):
    url: str = Field(description="Rerank server url.")
    top_n: int = Field(description="Top N nodes to return.")

    def __init__(
        self,
        top_n: int,
        url: str,
    ):
        super().__init__(url=url, top_n=top_n)

    def rerank(self, query, texts):
        url = f"{self.url}/rerank"
        request_body = {"query": query, "texts": texts, "truncate": False}
        response = requests.post(url, json=request_body)
        if response.status_code != 200:
            raise RuntimeError(f"Failed to rerank, detail: {response}")
        return response.json()

    @classmethod
    def class_name(cls) -> str:
        return "BgeRerank"

    def _postprocess_nodes(
        self,
        nodes: List[NodeWithScore],
        query_bundle: Optional[QueryBundle] = None,
    ) -> List[NodeWithScore]:
        if query_bundle is None:
            raise ValueError("Missing query bundle in extra info.")
        if len(nodes) == 0:
            return []

        texts = [node.text for node in nodes]
        results = self.rerank(
            query=query_bundle.query_str,
            texts=texts,
        )

        new_nodes = []
        for result in results[0 : self.top_n]:
            new_node_with_score = NodeWithScore(
                node=nodes[int(result["index"])].node,
                score=result["score"],
            )
            new_nodes.append(new_node_with_score)
        return new_nodes


docs = SimpleDirectoryReader(input_files=["../../data/yiyan.txt"]).load_data()
nodes = SentenceSplitter(chunk_size=100,chunk_overlap=0).get_nodes_from_documents(docs)
vector_index = VectorStoreIndex(nodes)

retriever =vector_index.as_retriever(similarity_top_k=5)
nodes = retriever.retrieve("百度文心一言的逻辑推理能力怎么样？")
print('================before rerank================')
print_nodes(nodes)

customRerank = BgeRerank(url="http://localhost:8080",top_n=2)
rerank_nodes = customRerank.postprocess_nodes(nodes,query_str='百度文心一言的逻辑推理能力怎么样?')
print('================after rerank================')
print_nodes(rerank_nodes)
""" 
synthesizer = get_response_synthesizer()
response = synthesizer.synthesize("百度文心一言的逻辑推理能力怎么样？",nodes=rerank_nodes)
pprint_response(response,show_source=True) 
 """