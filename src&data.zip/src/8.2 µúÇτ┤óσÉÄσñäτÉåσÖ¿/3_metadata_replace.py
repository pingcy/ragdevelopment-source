
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.postprocessor import MetadataReplacementPostProcessor
from llama_index.core.response.pprint_utils import pprint_response

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore

import pprint
import chromadb
import sys
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

#model
llm = Ollama(model='qwen:14b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm
Settings.embed_model=embedded_model

#vector store
chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="postprocessor")
vector_store = ChromaVectorStore(chroma_collection=collection)

#doc store
docstore = SimpleDocumentStore()

#documents
#docs = SimpleDirectoryReader(input_files=["../../data/yiyan.txt"]).load_data()
docs = [Document(text="小麦手机是小麦公司最新出的第十代手机产品。\
                      采用了中国最先进的国产红旗CPU芯片。\
                      采用了6.95寸的OLED显示屏幕与5000毫安的电池容量。")]

#splitter
node_parser = SentenceWindowNodeParser.from_defaults(
    sentence_splitter=my_chunking_tokenizer_fn,
    window_size=3,
    window_metadata_key="window",
    original_text_metadata_key="original_text",
)
nodes = node_parser.get_nodes_from_documents(docs)
print_nodes(nodes)

vector_index = VectorStoreIndex(nodes=nodes)
query_engine = vector_index.as_query_engine(
    similarity_top_k=1,
    node_postprocessors=[
        MetadataReplacementPostProcessor ( target_metadata_key = "window" ) 
    ],
)
window_response = query_engine.query(
    "小麦手机是哪个公司出品，采用什么芯片？"
)
pprint_response(window_response,show_source=True)