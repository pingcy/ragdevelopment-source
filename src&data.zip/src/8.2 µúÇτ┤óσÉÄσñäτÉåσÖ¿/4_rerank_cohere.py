
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.postprocessor import MetadataReplacementPostProcessor,FixedRecencyPostprocessor,EmbeddingRecencyPostprocessor,LongContextReorder
from llama_index.postprocessor.cohere_rerank import CohereRerank
from llama_index.core.response.pprint_utils import pprint_response

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore

import pprint
import chromadb
import sys
import os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

#model
llm = Ollama(model='qwen:14b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm
Settings.embed_model=embedded_model

docs = SimpleDirectoryReader(input_files=["../../data/yiyan.txt"]).load_data()
nodes = SentenceSplitter(chunk_size=100,chunk_overlap=0).get_nodes_from_documents(docs)
vector_index = VectorStoreIndex(nodes)

retriever =vector_index.as_retriever(similarity_top_k=5)
nodes = retriever.retrieve("百度文心一言的逻辑推理能力怎么样？")
print('================before rerank================')
print_nodes(nodes)

cohere_rerank = CohereRerank(model='rerank-multilingual-v3.0',api_key='*', top_n=2)
rerank_nodes = cohere_rerank.postprocess_nodes(nodes,query_str='百度文心一言的逻辑推理能力怎么样?')
print('================after rerank================')
print_nodes(rerank_nodes)

synthesizer = get_response_synthesizer()
response = synthesizer.synthesize("百度文心一言的逻辑推理能力怎么样？",nodes=rerank_nodes)
pprint_response(response,show_source=True) 