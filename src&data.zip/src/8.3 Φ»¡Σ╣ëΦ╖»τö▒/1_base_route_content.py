from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent,NodeWithScore
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.postprocessor import MetadataReplacementPostProcessor,SimilarityPostprocessor,KeywordNodePostprocessor,MetadataReplacementPostProcessor
from llama_index.core.postprocessor.types import BaseNodePostprocessor
from llama_index.core.response.pprint_utils import pprint_response
from llama_index.core.data_structs import Node
from llama_index.core import QueryBundle
from llama_index.core.query_engine import RouterQueryEngine
from llama_index.core.selectors import PydanticSingleSelector
from llama_index.core.tools import QueryEngineTool

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore
from typing import List,Optional
from llama_index.core.selectors import LLMSingleSelector, LLMMultiSelector

import pprint
import chromadb
import sys
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
import re
enable_trace()

#model
llm = Ollama(model='qwen:14b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm
Settings.embed_model=embedded_model

#documents
docs_xiaomai = SimpleDirectoryReader(input_files=["../../data/xiaomai.txt"]).load_data()
docs_yiyan = SimpleDirectoryReader(input_files=["../../data/yiyan.txt"]).load_data()

vectorindex_xiaomai = VectorStoreIndex.from_documents(docs_xiaomai)
query_engine_xiaomai = vectorindex_xiaomai.as_query_engine()

vectorindex_yiyan = VectorStoreIndex.from_documents(docs_yiyan)
query_engine_yiyan = vectorindex_yiyan.as_query_engine()
    
tool_xiaomai = QueryEngineTool.from_defaults(
    query_engine=query_engine_xiaomai,
    description="用来查询小麦手机的信息",
)
tool_yiyan = QueryEngineTool.from_defaults(
    query_engine=query_engine_yiyan,
    description="用来查询文心一言的信息",
)

query_engine = RouterQueryEngine(
    selector=LLMSingleSelector.from_defaults(),
    query_engine_tools=[
        tool_xiaomai,tool_yiyan
    ]
)
response = query_engine.query("什么是文心一言，用中文回答")
pprint_response(response,show_source=True)