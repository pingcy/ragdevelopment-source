from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.tools import ToolMetadata
from llama_index.core.selectors import LLMSingleSelector

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore
from typing import List,Optional
from llama_index.core.selectors import LLMSingleSelector, LLMMultiSelector
from llama_index.core.tools import RetrieverTool

import pprint
import chromadb
import sys
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
import re
enable_trace()

#model
llm = Ollama(model='qwen:14b')
Settings.llm=llm 
""" 

# choices as a list of tool metadata
choices = [
    ToolMetadata(description="description for choice 1", name="choice_1"),
    ToolMetadata(description="description for choice 2", name="choice_2"),
]
 """
# choices as a list of strings
choices = [
    ToolMetadata(description="查询当前实时的信息", name="web_search"),
    ToolMetadata(description="知识查询或内容创作",  name="query_engine")
]

selector = LLMSingleSelector.from_defaults()
selector_result = selector.select(
    choices, query="写一个悬疑小故事?"
)
print(selector_result.selections)