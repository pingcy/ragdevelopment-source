from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent,NodeWithScore
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.postprocessor import MetadataReplacementPostProcessor,SimilarityPostprocessor,KeywordNodePostprocessor,MetadataReplacementPostProcessor
from llama_index.core.postprocessor.types import BaseNodePostprocessor
from llama_index.core.response.pprint_utils import pprint_response
from llama_index.core.data_structs import Node
from llama_index.core import QueryBundle
from llama_index.core.query_engine import RouterQueryEngine
from llama_index.core.selectors import PydanticSingleSelector,LLMMultiSelector
from llama_index.core.tools import QueryEngineTool

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore
from typing import List,Optional
from llama_index.core import SimpleKeywordTableIndex
from llama_index.core import SummaryIndex

import pprint
import chromadb
import sys
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
import re
enable_trace()

#model
llm = Ollama(model='qwen:14b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm
Settings.embed_model=embedded_model

#documents
docs = SimpleDirectoryReader(input_files=["../../data/xiaomai.txt"]).load_data()

summary_index = SummaryIndex.from_documents(docs,chunk_size=100,chunk_overlap=0)
vector_index = VectorStoreIndex.from_documents(docs,chunk_size=100,chunk_overlap=0)
keyword_index = SimpleKeywordTableIndex.from_documents(docs,chunk_size=100,chunk_overlap=0)

summary_tool = QueryEngineTool.from_defaults( 
    query_engine=summary_index.as_query_engine(response_mode="tree_summarize",),
    description=(
        "有助于总结小麦手机相关的问题"
    ),
)

vector_tool = QueryEngineTool.from_defaults(
    query_engine=vector_index.as_query_engine(),
    description=(
        "适合检索与小麦手机相关的特定上下文"
    ),
)

keyword_tool = QueryEngineTool.from_defaults(
    query_engine=keyword_index.as_query_engine(),
    description=(
        "适合使用关键词从文章中检索特定的上下文"
    ),
)

query_engine = RouterQueryEngine(
    selector=LLMMultiSelector.from_defaults(),
    query_engine_tools=[
        summary_tool,vector_tool,keyword_tool
    ],verbose=True
)
response = query_engine.query("小麦手机的处理器是什么？")
pprint_response(response,show_source=True)