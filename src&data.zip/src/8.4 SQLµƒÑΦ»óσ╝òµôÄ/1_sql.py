from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.core import SQLDatabase

import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)

Settings.llm=llm_ollama
Settings.embed_model=embedded_model

from sqlalchemy import (
    create_engine,
    MetaData,
    Table,
    Column,
    String,
    Integer,
    select,text
)
from sqlalchemy.orm import sessionmaker

engine = create_engine("postgresql://postgres:*@localhost:5432/postgres")
sql_database = SQLDatabase(engine, include_tables=["customers","orders"])

""" 
with engine.connect() as conn:
    result = conn.execute(text("SELECT * FROM customers"))
    for row in result:
        print(row) 
"""

from llama_index.core.query_engine import NLSQLTableQueryEngine

#创建SQLTable查询引擎
llm_openai = OpenAI(model='gpt-3.5-turbo')
query_engine = NLSQLTableQueryEngine(
    sql_database=sql_database, tables=["customers","orders"], llm=llm_openai
)

response = query_engine.query("一共有多少个订单")
print(response)

