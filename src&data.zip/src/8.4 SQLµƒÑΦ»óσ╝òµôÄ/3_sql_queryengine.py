from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.core import SQLDatabase

import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)

Settings.llm=llm_ollama
Settings.embed_model=embedded_model

from sqlalchemy import (
    create_engine,
    MetaData,
    Table,
    Column,
    String,
    Integer,
    select,text
)
from sqlalchemy.orm import sessionmaker

engine = create_engine("postgresql://postgres:*@localhost:5432/postgres")
metadata_obj = MetaData()
sql_database = SQLDatabase(engine, include_tables=["customers","orders"])

""" 
with engine.connect() as conn:
    result = conn.execute(text("SELECT * FROM customers"))
    for row in result:
        print(row) 
"""
from llama_index.core.retrievers import NLSQLRetriever

# default retrieval (return_raw=True)
nl_sql_retriever = NLSQLRetriever(
    sql_database, tables=["customers","orders"], return_raw=True
)

from llama_index.core.query_engine import RetrieverQueryEngine

query_engine = RetrieverQueryEngine.from_args(nl_sql_retriever)
response = query_engine.query(
    "所有订单总金额是多少？"
)
print(response)