from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,KeywordTableIndex
from llama_index.core import DocumentSummaryIndex
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.response.pprint_utils import pprint_response
from llama_index.core.query_engine import TransformQueryEngine
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.retrievers.bm25 import BM25Retriever
from llama_index.core.retrievers import BaseRetriever,AutoMergingRetriever
from typing import List
from llama_index.core.schema import NodeWithScore
from llama_index.core.query_engine import MultiStepQueryEngine
from llama_index.core.indices.query.query_transform import HyDEQueryTransform,DecomposeQueryTransform,StepDecomposeQueryTransform
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser,HierarchicalNodeParser
from llama_index.core.node_parser import get_leaf_nodes, get_root_nodes
import pprint
from llama_index.core import QueryBundle
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.agent import AgentRunner
from llama_index.agent.openai import OpenAIAgentWorker, OpenAIAgent
from llama_index.agent.openai import OpenAIAgentWorker
from tqdm.asyncio import tqdm
from llama_parse import LlamaParse
from llama_index.vector_stores.chroma import ChromaVectorStore
import nest_asyncio,asyncio
from llama_index.core.storage.docstore import SimpleDocumentStore
nest_asyncio.apply()

import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

os.environ["LLAMA_CLOUD_API_KEY"] = "llx-*"

DEFAULT_SUMMARY_QUERY_STR = """\
请用中文简要介绍下表格内容。\
这个表格是关于什么的？给出一个非常简洁的摘要（想象你正在为这个表格添加一个新的标题和摘要），\
如果提供了上下文，请输出真实/现有的表格标题/说明。\
如果提供了上下文，请输出真实/现有的表格ID。\
还要输出表格是否应该保留的信息。\
"""

#llm & embedding model
os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm = llm_ollama
Settings.embed_model = embedded_model_openai

#vector store
chroma = chromadb.HttpClient(host="localhost", port=8000)
chroma.delete_collection('auto_retrieve')

#documents = LlamaParse(result_type="markdown",language='ch_sim').load_data("../../data/yiyan.txt")

documents = SimpleDirectoryReader(input_files=["../../data/citys/南京市.txt"]).load_data()
print(f'{len(documents)} documents loaded.\n')

def create_retriever(documents):
    node_parser = HierarchicalNodeParser.from_defaults(chunk_overlap=0)
    nodes = node_parser.get_nodes_from_documents(documents)
    print(f'{len(nodes)} nodes created.\n')

    collection = chroma.get_or_create_collection(name="auto_retrieve", metadata={"hnsw:space": "cosine"}) 
    vector_store = ChromaVectorStore(chroma_collection=collection)
    docstore = SimpleDocumentStore()
    docstore.add_documents(nodes)
    storage_context = StorageContext.from_defaults(vector_store=vector_store,docstore=docstore)

    leaf_nodes = get_leaf_nodes(nodes)
    root_nodes = get_root_nodes(nodes)
    print(f'leaf nodes: {len(leaf_nodes)}')
    print(f'root nodes: {len(root_nodes)}')

    leaf_index = VectorStoreIndex(
        nodes=leaf_nodes,
        storage_context=storage_context
    )
    leaf_retriever = leaf_index.as_retriever(similarity_top_k=1)

    retriever = AutoMergingRetriever(leaf_retriever, storage_context, verbose=True,simple_ratio_thresh = 0.1)
    return retriever,leaf_retriever

retriever,leaf_retriever = create_retriever(documents)

leaf_nodes = leaf_retriever.retrieve("南京市有哪些主要的旅游景点") 
print('\n---------------leaf nodes------------------\n')
print_nodes(leaf_nodes)

nodes = retriever.retrieve("南京市有哪些主要的旅游景点") 
print('\n---------------nodes------------------\n')
print_nodes(nodes)
 