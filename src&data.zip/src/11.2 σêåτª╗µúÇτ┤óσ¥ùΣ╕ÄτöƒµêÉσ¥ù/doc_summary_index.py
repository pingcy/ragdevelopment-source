from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,DocumentSummaryIndex
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor

from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.vector_stores.chroma import ChromaVectorStore

import pprint
import chromadb
from multiprocessing import freeze_support, set_start_method


#model
llm = Ollama(model='qwen:14b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm
Settings.embed_model=embedded_model

#vector store
chroma = chromadb.HttpClient(host="localhost", port=8000)
chroma.delete_collection(name="vectorindex")
collection = chroma.get_or_create_collection(name="vectorindex", metadata={"hnsw:space": "cosine"})
vector_store = ChromaVectorStore(chroma_collection=collection)
storage_context = StorageContext.from_defaults(vector_store=vector_store)

#doc store 
docstore = SimpleDocumentStore()

#read
#docs = SimpleDirectoryReader(input_files=["../../data/sales_tips1.txt","../../data/yiyan.txt"]).load_data()
docs = [Document(text="小麦智能健康手环是一款集健康监测、运动追踪与智能提醒于一体的可穿戴设备。它具备心率监测、血压测量、睡眠分析等多项功能，能够全方位关注用户的健康状况。手环内置高精度传感器，能够准确记录用户的运动数据，包括步数、卡路里消耗等，帮助用户更好地管理自己的运动计划。此外，智能提醒功能能够根据用户的日常习惯，提醒其按时喝水、吃药等，让用户的生活更加便捷和健康。",metadata={"title":"智家机器人"},doc_id="doc1"),Document(text="速达飞行者是一种飞行汽车，能够让您在城市中翱翔自如，体验全新的出行方式。",metadata={"title":"速达飞行者"},doc_id="doc2")]
doc_summary_index = DocumentSummaryIndex.from_documents(docs,
                                                        storage_context=storage_context,
                                                        summary_query="用中文描述所给文本的主要内容；同时描述这段文本可以回答的一些问题。")

pprint.pprint(doc_summary_index.get_document_summary("doc1"))

query_engine = doc_summary_index.as_query_engine(
    response_mode="tree_summarize", use_async=True
)
response = query_engine.query('小麦智能手环有哪些功能')
print(response)
#nodes = doc_summary_index._vector_store.query(VectorStoreQuery(query_str='小麦智能手环？',similarity_top_k=1)).nodes
#pprint.pprint(doc_summary_index._vector_store.__dict__)