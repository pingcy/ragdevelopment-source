from llama_index.core import SimpleDirectoryReader
from llama_index.core.readers.base import BaseReader
from llama_index.core.schema import Document,TextNode,MetadataMode
from llama_index.readers.file import ImageReader
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,TokenTextSplitter
from llama_index.core.node_parser.file import MarkdownNodeParser,HTMLNodeParser,JSONNodeParser,SimpleFileNodeParser

from llama_index.core.node_parser.text.utils import (
    split_by_char,
    split_by_regex,
    split_by_sentence_tokenizer,
    split_by_sep,
)
from pathlib import Path, PurePosixPath
import pprint
import chromadb
import sys
sys.path.append("..")

from tools import enable_trace,print_attrs,print_nodes
import csv
enable_trace()

def print_docs(docs:list[Document]):
    print('Count of documents:',len(docs))
    for index,doc in enumerate(docs):
        print("-----")
        print(f"Document {index}")
        print(doc.get_content(metadata_mode=MetadataMode.ALL))
        print("-----")


input_files = [ 
    "../../data/questions.csv"
]

def read_csv_file(file_path):
    
    nodes = []
    
    with open(file_path, 'r') as file:
        csv_reader = csv.reader(file)
        
        for row in csv_reader:
            question = row[0]
            answer = row[1]
            
            node = TextNode(text=question, metadata={"answer":answer})
            node.excluded_embed_metadata_keys = ["answer"]
            node.text_template = "{content}\n{metadata_str}\n"
            nodes.append(node)
    
    return nodes

# Example usage:
csv_file_path = "../../data/questions.csv"
nodes = read_csv_file(csv_file_path)

for node in nodes:
    print('Embed content:')
    print(node.get_content(metadata_mode=MetadataMode.EMBED))
    print('LLM content:')
    print(node.get_content(metadata_mode=MetadataMode.LLM))

