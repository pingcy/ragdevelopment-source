
from typing import Any, Callable, Dict, List, Optional, Tuple
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.openai import OpenAI
from llama_index.core.llama_dataset.generator import RagDatasetGenerator
from llama_index.core.llama_dataset import LabelledRagDataset
import pprint

# define llm and embedding model
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='qwen2')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_ollama
Settings.embed_model=embedded_model_openai

# build documents
docs =SimpleDirectoryReader(input_files = ['../../data/citys/南京市.txt']).load_data()

# define generator, generate questions
dataset_generator = RagDatasetGenerator.from_documents(
    documents=docs,
    llm=llm_ollama,
    num_questions_per_chunk=1,  # 设置每个节点的问题数量
    show_progress=True,
    question_gen_query="您是一位老师。您的任务是为即将到来的考试设置{num_questions_per_chunk}个问题。这些问题必须基于提供的上下文信息生成，并确保上下文信息能够回答这些问题。确保每一行只有一个独立的问题。不要有多余解释。不要问题编号。"
)

import myprompts
dataset_generator.update_prompts({
    "text_question_template": myprompts.MY_QUESTION_GENERATION_PROMPT,
    "text_qa_template": myprompts.MY_TEXT_QA_PROMPT,
})

""" 
print('Generating questions from nodes...\n')
rag_dataset = dataset_generator.generate_dataset_from_nodes()
rag_dataset.save_json('./rag_eval_dataset.json') 
"""

print('Loading dataset...\n')
rag_dataset = LabelledRagDataset.from_json('./rag_eval_dataset.json')
for example in rag_dataset.examples:
    print(f'query: {example.query}')
    print(f'answer: {example.reference_answer}')
