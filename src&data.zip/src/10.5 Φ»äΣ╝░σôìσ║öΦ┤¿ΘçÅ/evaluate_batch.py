from typing import Any, Callable, Dict, List, Optional, Tuple
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate,SummaryIndex
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.vector_stores.chroma import ChromaVectorStore
from multiprocessing import freeze_support, set_start_method
from llama_index.core.storage import StorageContext
from llama_index.core import load_index_from_storage
from llama_index.llms.openai import OpenAI
from llama_index.core import VectorStoreIndex
import chromadb
import pprint,chromadb,sys,os
from llama_index.core.evaluation import FaithfulnessEvaluator, CorrectnessEvaluator, RelevancyEvaluator,SemanticSimilarityEvaluator,AnswerRelevancyEvaluator,ContextRelevancyEvaluator
from llama_index.core.llama_dataset import LabelledRagDataset

import nest_asyncio
nest_asyncio.apply()

llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_ollama = Ollama(model='qwen2')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_ollama
Settings.embed_model=embedded_model_openai

chroma = chromadb.HttpClient(host="localhost", port=8000)
collection = chroma.get_or_create_collection(name="docs_agent_collection") 
vector_store = ChromaVectorStore(chroma_collection=collection)

HOME_DIR='/Users/pingcy/本地开发/rag'
DATA_DIR = f'{HOME_DIR}/data/citys'
STOR_DIR = f'./storage'

city_docs = {
    "Beijing":f'{DATA_DIR}/北京市.txt',
    "Guangzhou":f'{DATA_DIR}/广州市.txt',
    "Nanjing":f'{DATA_DIR}/南京市.txt',
    "Shanghai":f'{DATA_DIR}/上海市.txt'
}

def _create_doc_engine(name:str):

    file = city_docs[name]

    print(f'Starting to create document agent for 【{name}】...\n')
    docs =SimpleDirectoryReader(input_files = [file]).load_data()
    splitter = SentenceSplitter(chunk_size=500,chunk_overlap=50)
    nodes = splitter.get_nodes_from_documents(docs)
    
    # Create a vector index
    if not os.path.exists(f"{STOR_DIR}/{name}"):
        print('Creating vector index...\n')
        storage_context =  StorageContext.from_defaults(vector_store=vector_store)
        vector_index = VectorStoreIndex(nodes,storage_context=storage_context)
        vector_index.storage_context.persist(persist_dir=f"{STOR_DIR}/{name}")
    else:
        print('Loading vector index...\n')
        storage_context =  StorageContext.from_defaults(persist_dir=f"{STOR_DIR}/{name}",vector_store=vector_store)
        vector_index = load_index_from_storage(storage_context=storage_context)

    query_engine = vector_index.as_query_engine(similarity_top_k=5)

    return query_engine

query_engine = _create_doc_engine('Nanjing')

""" 
query = "南京有哪些优秀的旅游景点？请简单介绍。"
response = query_engine.query(query)
print(f'response: {response}\n') 
"""

# create evaluators
faithfulness_evaluator= FaithfulnessEvaluator()
relevancy_evaluator = RelevancyEvaluator()
correctness_evaluator = CorrectnessEvaluator()
similartiy_evaluator = SemanticSimilarityEvaluator()

# Load the dataset
rag_dataset = LabelledRagDataset.from_json('./rag_eval_dataset.json')
querys = []
for example in rag_dataset.examples:
    print(f'query: {example.query}')
    querys.append(example.query)

from llama_index.core.evaluation import BatchEvalRunner
import asyncio

runner = BatchEvalRunner(
    {"faithfulness": faithfulness_evaluator, 
     "relevancy": relevancy_evaluator,
     "correctness": correctness_evaluator,
     "similarity": similartiy_evaluator},
     workers=4
)

async def evaluate_queries():
    eval_results = await runner.aevaluate_queries(
        query_engine, 
        queries=[example.query for example in rag_dataset.examples][:10],
        reference=[example.reference_answer for example in rag_dataset.examples][:10],
    )
    return eval_results

# Call the async function
eval_results = asyncio.run(evaluate_queries()) 

import pandas as pd
def display_results(eval_results): 
    data = {} 
    
    for key, results in eval_results.items(): 
        scores = [result.score for result in results]
        scores.append(sum(scores) / len(scores))
        data[key] = scores 

    data["query"] = [result.query for result in eval_results["faithfulness"]]
    data["query"].append("【Average】")
    df = pd.DataFrame(data) 
    print(df)

display_results(eval_results)
