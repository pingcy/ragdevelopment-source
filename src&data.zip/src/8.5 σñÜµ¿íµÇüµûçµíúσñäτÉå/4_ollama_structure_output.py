from llama_index.multi_modal_llms.ollama import OllamaMultiModal

from pathlib import Path
from llama_index.core import SimpleDirectoryReader
from PIL import Image
import matplotlib.pyplot as plt
from llama_index.multi_modal_llms.dashscope import (
    DashScopeMultiModal,
    DashScopeMultiModalModels,
)
from llama_index.multi_modal_llms.dashscope.utils import (
    create_dashscope_multi_modal_chat_message,
    load_local_images
)

from llama_index.core.base.llms.types import MessageRole
from llama_index.core.multi_modal_llms.generic_utils import load_image_urls
import pprint

dashscope_multi_modal_llm = DashScopeMultiModal(model_name=DashScopeMultiModalModels.QWEN_VL_PLUS)
mm_model = OllamaMultiModal(model="llava")
# load as image documents
image_documents = SimpleDirectoryReader(input_files=["../../data/xiaomi.png"]).load_data()

# batch set image_url field in image_documents
for doc in image_documents:
    doc.image_url = doc.metadata["file_path"]

from pydantic import BaseModel


class Phone(BaseModel):
    """Data model for an phone."""
    name: str
    cpu: str
    battery: str
    display: str

from llama_index.core.program import MultiModalLLMCompletionProgram
from llama_index.core.output_parsers import PydanticOutputParser

prompt_template_str = """\
{query_str}
请把结果作为一个Pydantic对象返回，对象格式如下:
"""

mm_program = MultiModalLLMCompletionProgram.from_defaults(
    output_parser=PydanticOutputParser(Phone),
    image_documents=image_documents,
    prompt_template_str=prompt_template_str,
    multi_modal_llm=dashscope_multi_modal_llm,
    verbose=True,
)

response = mm_program(query_str="请描述图片中的信息。")
pprint.pprint(response.__dict__)