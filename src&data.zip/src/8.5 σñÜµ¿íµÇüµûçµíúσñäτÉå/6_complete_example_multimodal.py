import os
os.environ["LLAMA_CLOUD_API_KEY"] = "*"

import sys
sys.path.append("..")

from tools import enable_trace
enable_trace()

from llama_parse import LlamaParse
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings  
from llama_index.core.schema import BaseNode, TextNode,MetadataMode, TransformComponent,ImageDocument
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.core.extractors import TitleExtractor

from llama_index.llms.openai import OpenAI
from llama_index.llms.langchain import LangChainLLM
from langchain_community.llms import QianfanLLMEndpoint
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.vector_stores.chroma import ChromaVectorStore

from llama_index.multi_modal_llms.dashscope import (
    DashScopeMultiModal,
    DashScopeMultiModalModels,
)
from llama_index.multi_modal_llms.dashscope.utils import (
    create_dashscope_multi_modal_chat_message,
    load_local_images
)

from llama_index.core.base.llms.types import MessageRole
from llama_index.core.multi_modal_llms.generic_utils import load_image_urls

import pprint
import chromadb
from typing import List
from multiprocessing import freeze_support, set_start_method

DEFAULT_SUMMARY_QUERY_STR = """\
请用中文简要介绍下表格内容。\
这个表格是关于什么的？给出一个非常简洁的摘要（想象你正在为这个表格添加一个新的标题和摘要），\
如果提供了上下文，请输出真实/现有的表格标题/说明。\
如果提供了上下文，请输出真实/现有的表格ID。\
还要输出表格是否应该保留的信息。\
"""

os.environ["DAHSCOPE_API_KEY"] = "sk-*"

#model
#llm =LangChainLLM(llm=QianfanLLMEndpoint(model="ERNIE-Bot-turbo"))
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16")
llm = Ollama(model='llama3:8b')
Settings.llm=llm
Settings.embed_model=embedded_model

#vector store
chroma = chromadb.HttpClient(host="localhost", port=8000)

#delete collection
def delete_collection():
    try:
        chroma.delete_collection("llamaparse_simple")
    except:
        pass

    try:
        chroma.delete_collection("llamaparse_recursive")
    except:
        pass

#documents
def load_docs():
    parser = LlamaParse(language='ch_sim',verbose=True)
    json_objs = parser.get_json_result("../../data/xiaomi14.pdf")

    json_list = json_objs[0]["pages"]
    print(f'{len(json_list)} documents loaded.\n')

    def print_json(json_obj, indent=0):
        for key, value in json_obj.items():
            print(f"{' ' * indent}Key: {key}, Value Type: {type(value)}")
            if isinstance(value, dict):
                print_json(value, indent + 4)
                    
            if isinstance(value, list):
                print(f"{' ' * (indent + 4)}Item Type Of List: {type(value[0])}")
                if isinstance(value[0], dict):
                    print_json(value[0], indent + 8)

    image_list = parser.get_images(json_objs, download_path="pdf_images")
    print(f'{len(image_list)} images loaded.\n')

    return json_list,image_list

def get_text_nodes(json_list: List[dict]):
    text_nodes = []
    for idx, page in enumerate(json_list):
        pprint.pprint(page)
        text_node = TextNode(text=page["text"], metadata={"page": page["page"]})
        text_nodes.append(text_node)
    return text_nodes

def get_image_text_nodes(image_list: List[dict]):
    img_text_nodes = []
    for idx,image in enumerate(image_list):
        response = ''
        response = get_text_of_image(image["path"])

        print(f'Image {idx} path: {image["path"]}')
        print(f'Image {idx} text: {response}')

        text_node = TextNode(text=str(response), metadata={"path": image["path"]})
        img_text_nodes.append(text_node)
    return img_text_nodes

def get_text_of_image(image_path):

    mm_llm = DashScopeMultiModal(model_name=DashScopeMultiModalModels.QWEN_VL_PLUS)
    image = load_local_images(["file://./" + image_path])

    #调用
    chat_message_local = create_dashscope_multi_modal_chat_message(
        "请详细描述图中的信息，包括图中的文字和图像。",
        MessageRole.USER, 
        image
    )
    chat_response = mm_llm.chat([chat_message_local])
    return chat_response.message.content[0]["text"]

def create_engine():

    (json_list,image_list) = load_docs()

    text_nodes = get_text_nodes(json_list)
    img_text_nodes = get_image_text_nodes(image_list)

    pprint.pprint('length of text nodes: ' + str(len(text_nodes)))
    pprint.pprint('length of image text nodes: ' + str(len(img_text_nodes)))

    collection = chroma.get_or_create_collection(name="llamaparse_mm")
    vector_store = ChromaVectorStore(chroma_collection=collection)
    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    index = VectorStoreIndex(
        nodes=text_nodes + img_text_nodes,
        storage_context=storage_context
    )

    query_engine = index.as_query_engine(similarity_top=5,verbose=True)
    return query_engine

delete_collection()
query_engine = create_engine()

if query_engine:
    while True:
        query = input("\n输入你的问题 (or 'q' to quit): ")
        if query == 'q':
            break

        if query == "":
            continue

        response = query_engine.query(query)
        print("\n**********************************************Response**********************************************")
        print(response)