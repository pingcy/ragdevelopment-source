from llama_index.multi_modal_llms.dashscope import (
    DashScopeMultiModal,
    DashScopeMultiModalModels,
)
from llama_index.multi_modal_llms.dashscope.utils import (
    create_dashscope_multi_modal_chat_message,
    load_local_images
)

from llama_index.core.base.llms.types import MessageRole
from llama_index.core.multi_modal_llms.generic_utils import load_image_urls

import pprint
import os
os.environ["DAHSCOPE_API_KEY"] = "sk-*"

#加载图片文档
image_documents1 = load_image_urls(["https://dashscope.oss-cn-beijing.aliyuncs.com/images/dog_and_girl.jpeg"])
image_documents2 = load_local_images(["file:///Users/pingcy/本地开发/rag/data/xiaomi.png"])

#视觉模型
dashscope_multi_modal_llm = DashScopeMultiModal(model_name=DashScopeMultiModalModels.QWEN_VL_PLUS)

#调用
chat_message_local = create_dashscope_multi_modal_chat_message(
    "请概括这两张图中的信息",
      MessageRole.USER, 
      image_documents1 + image_documents2
)
chat_response = dashscope_multi_modal_llm.chat([chat_message_local])

#打印结果
print(chat_response.message.content[0]["text"]) 