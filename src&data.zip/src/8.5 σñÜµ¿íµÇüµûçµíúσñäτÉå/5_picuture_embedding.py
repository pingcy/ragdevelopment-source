
import chromadb 
import pprint
import os
from chromadb.utils.embedding_functions import OpenCLIPEmbeddingFunction
from chromadb.utils.data_loaders import ImageLoader

# set defalut text and image embedding functions
embedding_function = OpenCLIPEmbeddingFunction()
image_loader = ImageLoader()

# create client and a new collection
chroma_client = chromadb.HttpClient(host="localhost", port=8000)
chroma_client.delete_collection("multimodal_collection")
chroma_collection = chroma_client.get_or_create_collection(
    "multimodal_collection",
    embedding_function=embedding_function,
    data_loader=image_loader,
)

image_uris = sorted([os.path.join('./jpgs/', image_name) for image_name in os.listdir('./jpgs/') if image_name.endswith('.jpg')])
ids = [str(i) for i in range(len(image_uris))]

chroma_collection.add(ids=ids, uris=image_uris)

retrieved = chroma_collection.query(query_texts=["很多辆汽车"], include=['data'], n_results=2)

print(retrieved["uris"])

exit(0)

vector_store = ChromaVectorStore(chroma_collection=chroma_collection)

# load documents
documents = SimpleDirectoryReader("./jpgs/",required_exts=".jpg").load_data()

# set up ChromaVectorStore and load in data
storage_context = StorageContext.from_defaults(vector_store=vector_store)
index = VectorStoreIndex.from_documents(
    documents,
    storage_context=storage_context,
)

retriever = index.as_retriever(similarity_top_k=5)
retrieval_results = retriever.retrieve("two man")
print(f'Number of retrieval results: {len(retrieval_results)}')

for r in retrieval_results:
    if isinstance(r.node, ImageNode):
        pprint.pprint(f'score:{r.score},path:{r.node.metadata["file_path"]}')
    else:
        pprint.pprint(r.node.text)