import os
os.environ["LLAMA_CLOUD_API_KEY"] = "*"

import sys
sys.path.append("..")

from tools import enable_trace
enable_trace()

import llama_index.core.prompts.default_prompts as default_prompts
default_prompts.DEFAULT_TEXT_QA_PROMPT_TMPL = (
    "以下是参考的上下文信息：\n"
    "---------------------\n"
    "{context_str}\n"
    "---------------------\n"
    "请回答以下问题：\n"
    "问题: {query_str}\n"
    "你的答案: "
)

from llama_parse import LlamaParse
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser,SimpleNodeParser,MarkdownElementNodeParser
from llama_index.core.extractors import TitleExtractor

from llama_index.llms.openai import OpenAI
from llama_index.llms.langchain import LangChainLLM
from langchain_community.llms import QianfanLLMEndpoint
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.vector_stores.chroma import ChromaVectorStore

import pprint
import chromadb
from multiprocessing import freeze_support, set_start_method

DEFAULT_SUMMARY_QUERY_STR = """\
请用中文简要介绍下表格内容。\
这个表格是关于什么的？给出一个非常简洁的摘要（想象你正在为这个表格添加一个新的标题和摘要），\
如果提供了上下文，请输出真实/现有的表格标题/说明。\
如果提供了上下文，请输出真实/现有的表格ID。\
还要输出表格是否应该保留的信息。\
"""

#model
#llm =LangChainLLM(llm=QianfanLLMEndpoint(model="ERNIE-Bot-turbo"))
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16")
Settings.llm=OpenAI()
Settings.embed_model=embedded_model

#vector store
chroma = chromadb.HttpClient(host="localhost", port=8000)

#documents
def load_docs():
    documents = LlamaParse(result_type="markdown",language='ch_sim').load_data("../../data/zte-report-simple.pdf")
    print(f'{len(documents)} documents loaded.\n')
    return documents

def load_docs_json():

    parser = LlamaParse(verbose=True,language='ch_sim')
    json_objs = parser.get_json_result("../../data/zte-report-simple.pdf")
    json_list = json_objs[0]["pages"]

    documents = []
    for _, page in enumerate(json_list):
        documents.append(
            Document(
                text=page.get("text"),
                metadata=page,
            )
        )
    return documents

def delete_collection():
    try:
        chroma.delete_collection("llamaparse_simple")
    except:
        pass

    try:
        chroma.delete_collection("llamaparse_recursive")
    except:
        pass

def create_engine_simple(documents):
    node_parser = SimpleNodeParser()
    nodes = node_parser.get_nodes_from_documents(documents)
    print(f'{len(nodes)} nodes created.\n')
    pprint.pprint(nodes[0].__dict__)

    collection = chroma.get_or_create_collection(name="llamaparse_simple", metadata={"hnsw:space": "cosine"}) 
    vector_store = ChromaVectorStore(chroma_collection=collection)
    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    index = VectorStoreIndex(
        nodes=nodes,
        storage_context=storage_context
    )

    query_engine = index.as_query_engine(similarity_top=10,verbose=True)
    return query_engine


def create_engine_recursive(documents):
    node_parser = MarkdownElementNodeParser(summary_query_str=DEFAULT_SUMMARY_QUERY_STR)
    nodes = node_parser.get_nodes_from_documents(documents)
    base_nodes, objects = node_parser.get_nodes_and_objects(nodes)

    collection = chroma.get_or_create_collection(name="llamaparse_recursive", metadata={"hnsw:space": "cosine"})
    vector_store = ChromaVectorStore(chroma_collection=collection)

    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    index = VectorStoreIndex(
        nodes=base_nodes + objects,
        storage_context=storage_context
    )

    query_engine = index.as_query_engine(similarity_top=10,verbose=True)
    return query_engine

# Check command line arguments
delete_collection()
if len(sys.argv) > 1 and sys.argv[1] == "-r":
    print('Using recursive engine...')
    engine = create_engine_recursive(load_docs())
else:
    print('Using simple engine...')
    engine = create_engine_simple(load_docs())

while True:
    query = input("\n输入你的问题 (or 'q' to quit): ")
    if query == 'q':
        break

    if query == "":
        continue

    response = engine.query(query)
    print("\n**********************************************Response**********************************************")
    print(response)