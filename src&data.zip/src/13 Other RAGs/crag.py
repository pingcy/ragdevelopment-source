
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,PromptTemplate
from llama_index.core.schema import BaseNode, MetadataMode, TransformComponent
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.extractors import TitleExtractor
from llama_index.core.storage import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores.types import VectorStoreQuery
from llama_index.core.ingestion import IngestionPipeline, IngestionCache
from llama_index.core.schema import TransformComponent
from llama_index.core.node_parser import SentenceSplitter,SimpleFileNodeParser,CodeSplitter,SentenceWindowNodeParser
from llama_index.core.extractors import TitleExtractor
from llama_index.core.query_pipeline.query import QueryPipeline
from llama_index.core.schema import Document, NodeWithScore
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.tools.google import GoogleSearchToolSpec
from llama_index.tools.tavily_research.base import TavilyToolSpec
from typing import Any, Dict, List
from llama_index.core.response.pprint_utils import pprint_response
import pprint
import chromadb
from multiprocessing import freeze_support, set_start_method
import sys
sys.path.append("..")

#model
llm = Ollama(model='qwen:14b')
llm_openai = OpenAI(model='gpt-3.5-turbo')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
embedded_model_openai = OpenAIEmbedding(model_name="text-embedding-3-small", embed_batch_size=50)
Settings.llm=llm_openai
Settings.embed_model=embedded_model_openai

DEFAULT_TEXT_QA_PROMPT_TMPL = (
    "以下是上下文信息\n"
    "---------------------\n"
    "{context_str}\n"
    "---------------------\n"
    "请仅根据上面的上下文信息，回答以下问题，不要编造其他内容。\n"
    "如果上下文中不存在相关信息，请拒绝回答。\n"
    "问题: {query_str}\n"
    "答案: "
)
text_qa_prompt = PromptTemplate(DEFAULT_TEXT_QA_PROMPT_TMPL)

EVALUATE_PROMPT_TEMPLATE="""您是一个评分人员，评估检索到的文档与用户问题的相关性。
        以下是检索到的文档：
        ----------------
        {context}
        ----------------
        
        以下是用户的问题：
        ----------------
        {query_str}
        ----------------
        如果文档包含与用户问题相关的关键词或语义，且有助于解答用户问题，请将其评为相关。
        请给出一个yes或no来表明文档是否与问题相关。
        注意只需要输出yes或no，不要有多余解释。
        """
evaluate_prompt = PromptTemplate(EVALUATE_PROMPT_TEMPLATE)

REWRITE_PROMPT_TEMPLATE= """你需要生成针对检索优化的问题。请根据输入内容，尝试推理其中的语义意图/含义。
        这是初始问题：
        ----------------
        {query_str}
        ----------------
        请提出一个改进的问题："""
rewrite_prompt = PromptTemplate(REWRITE_PROMPT_TEMPLATE)

#创建检索器
def create_retriever(file):
    docs = SimpleDirectoryReader(input_files=[file]).load_data()
    index = VectorStoreIndex.from_documents(docs)
    return index.as_retriever(similarity_top_k=3),index.as_query_engine(similarity_top_k=3)

#评估检索结果
def evaluate_nodes(query_str:str,retrieved_nodes: List[Document]):

    #构建一个评估的Chain
    evaluate_pipeline = QueryPipeline(chain=[evaluate_prompt, llm_openai])

    relevancy_results = []
    filtered_nodes = []
    need_search = False
    for node in retrieved_nodes:
        relevancy = evaluate_pipeline.run(
            context=node.text, query_str=query_str
        )
        
        if(relevancy.message.content.lower()=='yes'):
            filtered_nodes.append(node)
        else:
            need_search = True
    
    return filtered_nodes,need_search

#重写问题
def rewrite(query_str: str):
    new_query_str = llm_openai.predict(
        rewrite_prompt, query_str = query_str
    )
    return new_query_str

#搜索
def web_search(query_str:str):
    tavily_tool = TavilyToolSpec(api_key="tvly-*")
    search_results = tavily_tool.search(query_str,max_results=5)
    return "\n".join([result.text for result in search_results])

#回答
def query(query_str,context_str):
    response = llm_openai.predict(
        text_qa_prompt, context_str=context_str, query_str=query_str
    )
    return response

#documents
file_name = "../../data/citys/南京市.txt"
retriever,query_engine = create_retriever(file_name)

#问题
query_str = '南京人口数量与分布情况？参加2024年中考的学生数量有多少？(使用中文回答)'

#直接生成答案
response = query_engine.query(query_str)
print(f'-----------------Response from query engine-------------------')
pprint_response(response,show_source=True)


print(f'-----------------Response from CRAG-------------------')
retrieved_nodes = retriever.retrieve(query_str)
print(f'{len(retrieved_nodes)} nodes retrieved.\n')

filtered_nodes,need_search = evaluate_nodes(query_str,retrieved_nodes)
print(f'{len(filtered_nodes)} nodes relevant.\n')

filtered_texts = [node.text for node in filtered_nodes]
filtered_text = "\n".join(filtered_texts)
print(f'Filtered text:\n{filtered_text}\n')

if need_search:
    new_query_str = rewrite(query_str)
    print(f'New query: {new_query_str}\n')
    search_text = web_search(new_query_str)
    print(f'Searched text:\n{search_text}\n')

context_str = filtered_text + "\n" + search_text
response = query(query_str,context_str)
print(f'Final Response from crag: \n{response}')






    


