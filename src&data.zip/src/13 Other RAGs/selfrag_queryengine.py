from dataclasses import dataclass
from typing import Any, Dict, List,Tuple
import numpy as np

from llama_index.core.query_engine import CustomQueryEngine
from llama_index.llms.llama_cpp import LlamaCPP
from llama_index.core.base.base_retriever import BaseRetriever
from llama_index.core.response import Response
from llama_index.core.bridge.pydantic import Field
from llama_index.core.utils import print_text

#定义所有的标记性tokens
_TOKENS = {
    "retrieval": ["[No Retrieval]", "[Retrieval]", "[Continue to Use Evidence]"],
    "relevance": ["[Irrelevant]", "[Relevant]"],
    "support": ["[Fully supported]", "[Partially supported]", "[No support / Contradictory]"],
    "utility": ["[Utility:1]", "[Utility:2]", "[Utility:3]", "[Utility:4]", "[Utility:5]"],
    "ctrl": [
        "[No Retrieval]",
        "[Retrieval]",
        "[Continue to Use Evidence]",
        "[Irrelevant]",
        "[Relevant]",
        "[Fully supported]",
        "[Partially supported]",
        "[No support / Contradictory]",
        "<paragraph>",
        "</paragraph>",
        "[Utility:1]",
        "[Utility:2]",
        "[Utility:3]",
        "[Utility:4]",
        "[Utility:5]",
    ],
}

#格式化selfrag的prompt
def _format_prompt(input: str, paragraph: str = None) -> str:
    """
    格式化selfrag的提示信息。

    Args:
        input (str): 输入的指令。
        paragraph (str, optional): 段落。默认为None。

    Returns:
        str: 格式化后的提示信息。
    """
    prompt = f"### Instruction:\n{input}\n\n### Response:\n"
    if paragraph is not None:
        prompt += f"[Retrieval]<paragraph>{paragraph}</paragraph>"
    return prompt

#最终输出：去除其中特殊的token
def _postprocess_answer(answer: str) -> str:
    """
    对生成的答案进行后处理，去除其中的特殊token。

    Args:
        answer (str): 生成的答案。

    Returns:
        str: 处理后的答案。
    """
    for token in _TOKENS["ctrl"]:
        answer = answer.replace(token, "")
    if "</s>" in answer:
        answer = answer.replace("</s>", "")
    if "\n" in answer:
        answer = answer.replace("\n", "")
    if "<|endoftext|>" in answer:
        answer = answer.replace("<|endoftext|>", "")
    return answer

#计算relevance score
def _relevance_score(pred_log_probs: Dict[str, float]) -> float:
    """
    计算相关性得分。

    参数:
    - pred_log_probs (Dict[str, float]): 包含预测概率的字典，键为预测标签，值为对应的对数概率。

    返回值:
    - float: 相关性得分。

    """
    rel_prob = np.exp(float(pred_log_probs["[Relevant]"]))
    irel_prob = np.exp(float(pred_log_probs["[Irrelevant]"]))
    return rel_prob / (rel_prob + irel_prob)

#计算support score
def _is_supported_score(
    pred_tokens: List[int], pred_log_probs_dict: List[Dict[str, float]]
) -> float:
    """
    根据预测的tokens和它们的对数概率计算有用性分数。

    参数:
        pred_tokens (List[int]): 预测的tokens列表。
        pred_log_probs_dict (List[Dict[str, float]]): 包含每个token的对数概率的字典列表。

    返回值:
        float: 有用性分数。
    """
    isSup_score = 0
    support_token_appear_id = -1
    for tok_idx, token in enumerate(pred_tokens):
        if token in _TOKENS["support"]:
            support_token_appear_id = tok_idx
            break
    if support_token_appear_id > -1:
        grd_score_dict = {}
        for token in _TOKENS["support"]:
            prob = pred_log_probs_dict[support_token_appear_id][token]
            grd_score_dict[token] = np.exp(float(prob))
        isSup_score = (
            grd_score_dict["[Fully supported]"]
            + 0.5 * grd_score_dict["[Partially supported]"]
        ) / np.sum(list(grd_score_dict.values()))
    return isSup_score

#计算有用性分数
def _is_useful_score(
    pred_tokens: List[int], pred_log_probs_dict: List[Dict[str, float]]
) -> float:
    """
    计算有用分数。

    Args:
        pred_tokens (List[int]): 预测的令牌列表。
        pred_log_probs_dict (List[Dict[str, float]]): 预测的对数概率字典列表。

    Returns:
        float: 有用分数。
    """
    
    isUse_score = 0
    utility_token_appear_id = -1
    for tok_idx, tok in enumerate(pred_tokens):
        if tok in _TOKENS["utility"]:
            utility_token_appear_id = tok_idx
    if utility_token_appear_id > -1:
        ut_score_dict = {}
        for token in _TOKENS["utility"]:
            prob = pred_log_probs_dict[utility_token_appear_id][token]
            ut_score_dict[token] = np.exp(float(prob))

        ut_sum = np.sum(list(ut_score_dict.values()))
        ut_weights = [-1, -0.5, 0, 0.5, 1]
        isUse_score = np.sum(
            [
                ut_weights[i] * (ut_score_dict[f"[Utility:{i + 1}]"] / ut_sum)
                for i in range(len(ut_weights))
            ]
        )
    return isUse_score


class SelfRAGQueryEngine(CustomQueryEngine):

    llm: Any = Field(default=None, description="llm")
    retriever: BaseRetriever = Field(default=None, description="retriever")

    def __init__(
        self,
        llm: LlamaCPP,
        retriever: BaseRetriever,
    ) -> None:
        
        """初始化查询引擎"""
        super().__init__()
        self.llm = llm
        self.retriever = retriever

    def _regen_then_eval(self, paragraphs: List[str]) ->Tuple[Dict[int,str],Dict[int,float]]:
            """
            运行评判模块，对给定的段落进行生成，并评分。

            参数：
            paragraphs (List[str]): 包含要评分的段落的列表。

            返回：
            Tuple[Dict[int,str],Dict[int,float]]: 包含生成的结果索引和评分字典。

            """

            paragraphs_final_score = {}
            llm_response_text = {}

            for p_idx, paragraph in enumerate(paragraphs):
                response = self.llm.complete(paragraph)
                pred = response.raw
                llm_response_text[p_idx] = response.text

                logprobs = pred["choices"][0]["logprobs"]
                pred_log_probs = logprobs["top_logprobs"]

                # 计算isRel分数，使用第一个预测的标记
                isRel_score = _relevance_score(pred_log_probs[0])

                # 计算isSup分数
                isSup_score = _is_supported_score(logprobs["tokens"], pred_log_probs)

                # 计算isUse分数
                isUse_score = _is_useful_score(logprobs["tokens"], pred_log_probs)

                #最终得分
                paragraphs_final_score[p_idx] = (
                    isRel_score + isSup_score + 0.5 * isUse_score
                )

                print_text(
                    f"输入: {paragraph}\n响应: {llm_response_text[p_idx]}\n评分: {paragraphs_final_score[p_idx]}\n",
                    color="blue",
                 )
                print_text(
                    f"已完成 {p_idx + 1}/{len(paragraphs)} 段落\n\n", color="blue"
                )

            return llm_response_text, paragraphs_final_score

    def custom_query(self, query_str: str) -> str:
            """
            自定义查询函数。

            参数：
            query_str (str): 查询字符串。

            返回：
            Response: 查询的响应结果。
            """
            
            response = self.llm.complete(_format_prompt(query_str))
            answer = response.text

            if "[Retrieval]" in answer:

                print_text("需要检索知识，开始检索...\n", color="blue")
                documents = self.retriever.retrieve(query_str)
                print_text(f"共检索到 {len(documents)} 个相关知识\n", color="blue")

                paragraphs = [
                    _format_prompt(query_str, document.node.text) for document in documents
                ]

                print_text("=======================开始：重新生成并评估=======================\n", color="blue")
                llm_response_per_paragraph,paragraphs_final_score = \
                    self._regen_then_eval(paragraphs)
                print_text("=======================结束：重新生成并评估=======================\n", color="blue")

                best_paragraph_id = max(
                    paragraphs_final_score, key=paragraphs_final_score.get
                )
                answer = llm_response_per_paragraph[best_paragraph_id]
                print_text(f"已选择最佳答案: {answer}\n", color="blue")

            else:
                print_text("无需检索知识，直接输出答案\n",color="green")

            answer = _postprocess_answer(answer)
            print_text(f"最终答案: {answer}\n", color="green")
            return str(answer)

