import os
os.environ["OPENAI_API_KEY"] = "sk-*"
os.environ["OPENAI_API_BASE"] = "*"

from llama_index.llms.llama_cpp import LlamaCPP
from llama_index.core import Document, VectorStoreIndex
from llama_index.core.retrievers import VectorIndexRetriever
from pathlib import Path

from selfrag_queryengine import SelfRAGQueryEngine

_MODEL_KWARGS = {"logits_all": True, "n_ctx": 2048, "n_gpu_layers": -1}
_GENERATE_KWARGS = {
    "temperature": 0.0,
    "top_p": 1.0,
    "max_tokens": 500,
    "logprobs": 32016,
}

# 先前下载并保存Llama2模型的目录。
download_dir = "../../model"

# 创建测试文档
documents = [
    Document(
        text="Xiaomi 14 is the latest smartphone released by Xiaomi. It adopts a new design concept, the body is lighter and thinner, equipped with the latest processor, and the performance is more powerful."
    ),
    Document(
        text="Xiaomi 14 phone uses a 6.7-inch ultra-clear large screen, with a resolution of up to 2400x1080, whether watching videos or playing games, it can bring the ultimate visual experience."
    ),
    Document(
        text="Xiaomi 14 phone is equipped with the latest Snapdragon 888 processor, equipped with 8GB of running memory and 128GB of storage space, whether it is running large games or multitasking, it can easily cope."
    ),
    Document(
        text="Xiaomi 14 phone is equipped with a 5000mAh large-capacity battery, supports fast charging, even if you are traveling or using it for a long time, you don't have to worry about power issues."
    ),
    Document(
        text="Xiaomi 14 phone has a rear camera of 64 million pixels and a front camera of 20 million pixels. Whether it is taking pictures or recording videos, it can capture every wonderful moment in life."
    ),
    Document(
        text="Xiaomi 14 phone runs the latest MIUI 12 operating system. This operating system has a beautiful interface, smooth operation, and provides a wealth of functions and applications."
    ),
    Document(
        text="Xiaomi 14 phone supports 5G network, fast download speed, low latency, whether watching high-definition videos or playing online games, you can enjoy the ultimate network experience."
    ),
    Document(
        text="Xiaomi 14 phone supports facial recognition and fingerprint unlocking, protects user privacy, and provides a more convenient unlocking method."
    ),
    Document(
        text="Xiaomi 14 phone supports wireless charging and reverse charging functions. Wireless charging can free you from the shackles of data cables, and reverse charging can charge your other devices."
    ),
    Document(
        text="Xiaomi 14 phone is equipped with a 90Hz high refresh rate screen, whether scrolling pages or playing games, it can bring a smooth visual experience."
    ),
]

# index
index = VectorStoreIndex.from_documents(documents)

# retriever
retriever = VectorIndexRetriever(index=index,similarity_top_k=5)

# llm：采用llama_cpp
model_path = Path(download_dir) / "selfrag_llama2_7b.q4_k_m.gguf"
llm = LlamaCPP(model_path=str(model_path), model_kwargs=_MODEL_KWARGS, generate_kwargs=_GENERATE_KWARGS,verbose=False)

# 采用自定义查询引擎
query_engine = SelfRAGQueryEngine(llm, retriever)

# 查询一：无需检索的创作问题
print("\nQuery 1: write a poem about beautiful sunset")
response = query_engine.query("write a poem about beautiful sunset")

# 查询二：需要检索的事实性问题
print("\nQuery 2: Tell me some truth about xiaomi 14 phone, especially about its battery and camera?")
response = query_engine.query("Tell me some truth about xiaomi 14 phone, especially about its battery and camera?")
