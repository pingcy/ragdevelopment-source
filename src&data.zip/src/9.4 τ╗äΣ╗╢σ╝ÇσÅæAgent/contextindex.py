import json
from typing import Sequence, List
from llama_index.core.tools import BaseTool, FunctionTool
from llama_index.core.agent import ReActAgent
from llama_index.agent.openai import OpenAIAgent
from llama_index.llms.openai import OpenAI
from llama_index.core.agent import AgentRunner
from llama_index.agent.openai import OpenAIAgentWorker
from llama_index.core import VectorStoreIndex
from llama_index.core.objects import ObjectIndex
from llama_index.agent.openai_legacy import ContextRetrieverOpenAIAgent
from llama_index.core.schema import Document,TextNode,MetadataMode

import nest_asyncio
nest_asyncio.apply()

#搜索
def search_weather(query: str) -> str:
    """用于搜索天气情况"""
    # Perform search logic here
    search_results = f"明天天气晴转多云，最高温度30度，最低温度23度。天气炎热，注意防晒哦。"
    return search_results

tool_search = FunctionTool.from_defaults(fn=search_weather)

#发送邮件
def send_email(subject: str, recipient: str, message: str) -> None:
    """用于发送电子邮件"""
    # Send email logic here
    print(f"邮件已发送至 {recipient}，主题为 {subject}，内容为 {message}")

tool_send_mail = FunctionTool.from_defaults(fn=send_email)

#查询客户信息
def query_customer(phone: str) -> str:
    """用于查询客户信息"""
    # Perform creation logic here
    result = f"该客户信息为:\n姓名: 张三\n电话: {phone}\n地址: 北京市海淀区"
    return result

tool_customer = FunctionTool.from_defaults(fn=query_customer)

tools = [tool_search,tool_send_mail,tool_customer]

texts = [
    "Abbreviation: X = Revenue",
    "Abbreviation: YZ = Risk Factors",
    "Abbreviation: Z = Costs",
]

docs = [Document(text=t) for t in texts]
context_index = VectorStoreIndex.from_documents(docs)

llm = OpenAI(model="gpt-3.5-turbo")

# add context agent
context_agent = ContextRetrieverOpenAIAgent.from_tools_and_retriever(
    tools,
    context_index.as_retriever(similarity_top_k=1),
    verbose=True,
)

context_agent.chat('What is the YZ of March 2022')



