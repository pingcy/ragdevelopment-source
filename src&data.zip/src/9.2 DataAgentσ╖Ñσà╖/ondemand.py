
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.readers.web import AsyncWebPageReader,BeautifulSoupWebReader,NewsArticleReader,SimpleWebPageReader
from llama_index.core.tools.ondemand_loader_tool import OnDemandLoaderTool
from typing import List,Tuple,Any,Dict

from pydantic import BaseModel
import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm_ollama
Settings.embed_model=embedded_model



def _baidu_reader(
            soup: Any, url: str, include_url_in_text: bool = True
        ) -> Tuple[str, Dict[str, Any]]:
            main_content = soup.find(class_='main')
            if main_content:
                text = main_content.get_text()
            else:
                text = ''
            return text, {"title": soup.find(class_="post__title").get_text()}

web_loader = BeautifulSoupWebReader(website_extractor={"cloud.baidu.com":_baidu_reader})

tool_xiaomai = OnDemandLoaderTool.from_defaults(
    web_loader,
    name="tool_xiaomai",
    description="用来查询本地文件中的小麦手机信息",
)
output = tool_xiaomai.call(urls=["https://cloud.baidu.com/doc/AppBuilder/s/6lq7s8lli"],
                  query_str='百度云千帆appbuilder是什么？')

print(output)