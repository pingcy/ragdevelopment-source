
from llama_index.core import Document,SimpleDirectoryReader,VectorStoreIndex,Settings,get_response_synthesizer,PromptTemplate
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from llama_index.llms.dashscope import DashScope, DashScopeGenerationModels
from llama_index.core.tools import QueryEngineTool

import pprint,chromadb,sys,os
sys.path.append("..")
from tools import enable_trace,print_nodes,my_chunking_tokenizer_fn
enable_trace()

os.environ["DASHSCOPE_API_KEY"] = "sk-*"
llm_openai = OpenAI(model='gpt-3.5-turbo')
llm_dash = DashScope(model_name=DashScopeGenerationModels.QWEN_TURBO)
llm_ollama = Ollama(model='llama3:8b')
embedded_model = OllamaEmbedding(model_name="milkey/dmeta-embedding-zh:f16", embed_batch_size=50)
Settings.llm=llm_openai
Settings.embed_model=embedded_model


 #documents
docs1 = SimpleDirectoryReader(input_files=["../../data/xiaomai.txt"]).load_data()
docs2 = SimpleDirectoryReader(input_files=["../../data/xiaomaiUltra.txt"]).load_data()

index1 = VectorStoreIndex.from_documents(docs1)
index2 = VectorStoreIndex.from_documents(docs2)

query_xiaomai = index1.as_query_engine(response_mode="compact")
query_ultra = index2.as_query_engine(response_mode="compact")


query_tool_xiaomai = QueryEngineTool.from_defaults(
    query_engine=query_xiaomai,
    name="query_tool_xiaomai",
    description="提供小麦手机普通型号pro/max的信息")

query_tool_ultra = QueryEngineTool.from_defaults(
    query_engine=query_ultra,
    name="query_tool_ultra",
    description="提供小麦手机Ultra的信息")

from llama_index.core.tools import QueryPlanTool
from llama_index.core import get_response_synthesizer
from llama_index.core.tools.query_plan import QueryPlan, QueryNode

response_synthesizer = get_response_synthesizer()
query_plan_tool = QueryPlanTool.from_defaults(
    query_engine_tools=[query_tool_xiaomai, query_tool_ultra],
    response_synthesizer=response_synthesizer,
)
nodes=[
        QueryNode(
            id=1,
            query_str="查询小麦Pro手机信息",
            tool_name="query_tool_xiaomai",
            dependencies=[]
        ),
        QueryNode(
            id=2,
            query_str="查询小麦Ultra信息",
            tool_name="query_tool_ultra",
            dependencies=[1]
        ),
        QueryNode(
            id=3,
            query_str="对比小麦Pro与小麦Ultrl的配置区别",
            tool_name="vs_tool",
            dependencies=[1,2]
        )
    ]
output = query_plan_tool(nodes=nodes)
print(output)
""" 
from llama_index.agent.openai import OpenAIAgent
from llama_index.llms.openai import OpenAI

agent = OpenAIAgent.from_tools(
    [query_plan_tool],
    max_function_calls=5,
    verbose=True,
)
response = agent.query("对比小麦手机pro和Ultra的配置区别") """